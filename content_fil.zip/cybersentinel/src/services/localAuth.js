// src/services/localAuth.js
// Client-side authentication using localStorage

const USERS_KEY = 'cybersentinel_users';
const CURRENT_USER_KEY = 'cybersentinel_current_user';

// Simple hash function (for demo - use proper hashing in production)
const hashPassword = async (password) => {
  const encoder = new TextEncoder();
  const data = encoder.encode(password);
  const hash = await crypto.subtle.digest('SHA-256', data);
  return Array.from(new Uint8Array(hash))
    .map(b => b.toString(16).padStart(2, '0'))
    .join('');
};

// Get all users from localStorage
export const getAllUsers = () => {
  const users = localStorage.getItem(USERS_KEY);
  return users ? JSON.parse(users) : [];
};

// Save users to localStorage
const saveUsers = (users) => {
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
};

// Sign up new user
export const signUp = async (email, password, name) => {
  try {
    // Validation
    if (!email || !password || !name) {
      throw new Error('All fields are required');
    }

    if (password.length < 6) {
      throw new Error('Password must be at least 6 characters');
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      throw new Error('Invalid email format');
    }

    const users = getAllUsers();

    // Check if user already exists
    if (users.find(u => u.email === email)) {
      throw new Error('User already exists with this email');
    }

    // Hash password
    const hashedPassword = await hashPassword(password);

    // Create new user
    const newUser = {
      id: Date.now().toString(),
      name,
      email,
      password: hashedPassword,
      createdAt: new Date().toISOString(),
    };

    users.push(newUser);
    saveUsers(users);

    return { success: true, message: 'Account created successfully!' };
  } catch (error) {
    return { success: false, message: error.message };
  }
};

// Sign in user
export const signIn = async (email, password, rememberMe = false) => {
  try {
    if (!email || !password) {
      throw new Error('Email and password are required');
    }

    const users = getAllUsers();
    const hashedPassword = await hashPassword(password);

    // Find user
    const user = users.find(u => u.email === email && u.password === hashedPassword);

    if (!user) {
      throw new Error('Invalid email or password');
    }

    // Create session
    const session = {
      id: user.id,
      name: user.name,
      email: user.email,
      loginAt: new Date().toISOString(),
      rememberMe,
    };

    // Save current user
    if (rememberMe) {
      localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(session));
    } else {
      sessionStorage.setItem(CURRENT_USER_KEY, JSON.stringify(session));
    }

    return { success: true, message: 'Login successful!', user: session };
  } catch (error) {
    return { success: false, message: error.message };
  }
};

// Get current logged-in user
export const getCurrentUser = () => {
  const user = localStorage.getItem(CURRENT_USER_KEY) || 
               sessionStorage.getItem(CURRENT_USER_KEY);
  return user ? JSON.parse(user) : null;
};

// Check if user is authenticated
export const isAuthenticated = () => {
  return getCurrentUser() !== null;
};

// Sign out user
export const signOut = () => {
  localStorage.removeItem(CURRENT_USER_KEY);
  sessionStorage.removeItem(CURRENT_USER_KEY);
  return { success: true, message: 'Logged out successfully' };
};