// src/services/logsParser.js
// This service handles loading and parsing logs.json dynamically

/**
 * Load logs from public/logs.json
 */
export const loadLogs = async () => {
  try {
    console.log('📂 Loading logs from /logs.json...');
    
    const response = await fetch('/logs.json');
    
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    
    const text = await response.text();
    let logs = [];
    
    // Check if it's a JSON array or newline-delimited JSON
    if (text.trim().startsWith('[')) {
      // Standard JSON array
      logs = JSON.parse(text);
    } else {
      // Newline-delimited JSON (one object per line)
      logs = text
        .split('\n')
        .filter(line => line.trim())
        .map(line => {
          try {
            return JSON.parse(line);
          } catch (e) {
            console.warn('Failed to parse line:', line);
            return null;
          }
        })
        .filter(log => log !== null);
    }
    
    console.log(`✅ Successfully loaded ${logs.length} log entries`);
    return logs;
    
  } catch (error) {
    console.error('❌ Error loading logs:', error);
    throw error;
  }
};

/**
 * Calculate KPIs from logs
 */
export const calculateKPIs = (logs) => {
  const totalRequests = logs.length;
  const allowed = logs.filter(log => log.event === 'allowed').length;
  const blocked = logs.filter(log => log.event === 'blocked').length;
  const blockedPercentage = totalRequests > 0 
    ? ((blocked / totalRequests) * 100).toFixed(1) 
    : 0;
  
  return {
    totalRequests,
    allowed,
    blocked,
    blockedPercentage: parseFloat(blockedPercentage),
  };
};

/**
 * Get counter snapshots from the most recent log
 */
export const getCounterSnapshot = (logs) => {
  if (logs.length === 0) {
    return {
      blocked_watch: 0,
      blocked_api: 0,
      blocked_cdn_referer: 0,
      blocked_host: 0,
      blocked_prefix: 0,
      blocked_regex: 0,
      allowed: 0,
    };
  }
  
  // Find the most recent log with counters_snapshot
  const logWithCounters = [...logs]
    .reverse()
    .find(log => log.counters_snapshot);
  
  return logWithCounters?.counters_snapshot || {
    blocked_watch: 0,
    blocked_api: 0,
    blocked_cdn_referer: 0,
    blocked_host: 0,
    blocked_prefix: 0,
    blocked_regex: 0,
    allowed: 0,
  };
};

/**
 * Generate time series data grouped by hour
 */
export const generateTimeSeries = (logs, hours = 24) => {
  const now = Date.now();
  const hourMs = 3600000;
  
  // Create buckets for each hour
  const buckets = [];
  for (let i = hours - 1; i >= 0; i--) {
    const startTime = now - (i * hourMs);
    buckets.push({
      time: new Date(startTime).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
      timestamp: startTime,
      allowed: 0,
      blocked: 0,
    });
  }
  
  // Fill buckets with log data
  logs.forEach(log => {
    const logTime = log.timestamp ? log.timestamp * 1000 : new Date(log.timestamp_iso).getTime();
    const hourIndex = Math.floor((now - logTime) / hourMs);
    const bucketIndex = hours - 1 - hourIndex;
    
    if (bucketIndex >= 0 && bucketIndex < hours) {
      if (log.event === 'allowed') {
        buckets[bucketIndex].allowed++;
      } else if (log.event === 'blocked') {
        buckets[bucketIndex].blocked++;
      }
    }
  });
  
  return buckets;
};

/**
 * Get block reasons distribution
 */
export const getBlockReasons = (logs) => {
  const blockedLogs = logs.filter(log => log.event === 'blocked');
  const reasonCounts = {};
  
  blockedLogs.forEach(log => {
    const reason = log.block_reason || 'unknown';
    reasonCounts[reason] = (reasonCounts[reason] || 0) + 1;
  });
  
  const colors = {
    api: '#60A5FA',
    watch: '#A78BFA',
    regex: '#FB7185',
    host: '#5EEAD4',
    prefix: '#FCD34D',
    cdn_referer: '#F472B6',
    unknown: '#94A3B8',
  };
  
  return Object.entries(reasonCounts).map(([name, value]) => ({
    name: name.replace(/_/g, ' ').toUpperCase(),
    value,
    color: colors[name] || '#94A3B8',
  }));
};

/**
 * Get top blocked URLs
 */
export const getTopBlockedUrls = (logs, limit = 5) => {
  const blockedLogs = logs.filter(log => log.event === 'blocked');
  const urlCounts = {};
  
  blockedLogs.forEach(log => {
    const url = log.url || log.path || 'unknown';
    urlCounts[url] = (urlCounts[url] || 0) + 1;
  });
  
  return Object.entries(urlCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, limit)
    .map(([url, count]) => ({ url, count }));
};

/**
 * Extract YouTube video ID from URL
 */
const extractYouTubeVideoId = (url, host) => {
  if (!host.includes('youtube') && !host.includes('youtu.be')) {
    return null;
  }
  
  // Try to extract from query parameter
  const match = url.match(/[?&]v=([^&]+)/);
  if (match) return match[1];
  
  // Try to extract from youtu.be short link
  const shortMatch = url.match(/youtu\.be\/([^?]+)/);
  if (shortMatch) return shortMatch[1];
  
  return null;
};

/**
 * Get top blocked YouTube video IDs
 */
export const getTopBlockedVideos = (logs, limit = 5) => {
  const blockedLogs = logs.filter(log => log.event === 'blocked');
  const videoCounts = {};
  
  blockedLogs.forEach(log => {
    const videoId = extractYouTubeVideoId(log.url || '', log.host || '');
    if (videoId) {
      videoCounts[videoId] = (videoCounts[videoId] || 0) + 1;
    }
  });
  
  return Object.entries(videoCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, limit)
    .map(([videoId, count]) => ({ videoId, count }));
};

/**
 * Get top client IPs
 */
export const getTopClientIPs = (logs, limit = 4) => {
  const ipCounts = {};
  
  logs.forEach(log => {
    const ip = log.client_ip || 'unknown';
    ipCounts[ip] = (ipCounts[ip] || 0) + 1;
  });
  
  return Object.entries(ipCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, limit)
    .map(([ip, count]) => ({ ip, count }));
};

/**
 * Get recent logs (last N entries)
 */
export const getRecentLogs = (logs, limit = 10) => {
  return [...logs]
    .sort((a, b) => {
      const timeA = a.timestamp ? a.timestamp * 1000 : new Date(a.timestamp_iso).getTime();
      const timeB = b.timestamp ? b.timestamp * 1000 : new Date(b.timestamp_iso).getTime();
      return timeB - timeA;
    })
    .slice(0, limit)
    .map((log, index) => ({
      id: index + 1,
      timestamp: log.timestamp_iso || new Date(log.timestamp * 1000).toISOString(),
      host: log.host || 'unknown',
      url: log.url || log.path || '/',
      event: log.event || 'unknown',
      reason: log.block_reason || '-',
      ip: log.client_ip || 'unknown',
      method: log.method || 'GET',
      content_length: log.content_length || 0,
      headers: log.headers || {},
      fullData: log,
    }));
};

/**
 * Format timestamp for display
 */
export const formatTimestamp = (timestamp) => {
  if (!timestamp) return 'Unknown';
  
  const date = typeof timestamp === 'string' 
    ? new Date(timestamp)
    : new Date(timestamp * 1000);
  
  return date.toLocaleString('en-US', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  });
};