// src/pages/SignIn.jsx
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { signIn } from '../services/localAuth';
import { Shield, Mail, Lock, Eye, EyeOff, AlertCircle } from 'lucide-react';

const SignIn = () => {
  const navigate = useNavigate();
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    const result = await signIn(email, password, rememberMe);

    if (result.success) {
      navigate('/dashboard');
    } else {
      setError(result.message);
    }

    setLoading(false);
  };

  return (
    <div className="auth-container">
      <style>{authStyles}</style>

      <div className="auth-wrapper">
        {/* Left Side - Branding */}
        <div className="auth-branding">
          <div className="auth-branding">
            <div className="brand-content">

              <img src="/src/assets/cybersentinel.png" alt="CyberSentinel" className="brand-logo" />

              <h1>CyberSentinel</h1>
              <p>powered by Virtual Galaxy</p>
              <img src="/src/assets/vg_logo.png" alt="Virtual Galaxy" className="powered-by-logo" />

              <div className="brand-description">
                <p>Monitor and analyze your web traffic with powerful security insights.</p>
              </div>
            </div>
          </div>
        </div>

        {/* Right Side - Form */}
        <div className="auth-form-container">
          <div className="auth-card">
            {/* Toggle Buttons */}
            <div className="auth-toggle">
              <button
                className={`toggle-btn ${isLogin ? 'active' : ''}`}
                onClick={() => setIsLogin(true)}
              >
                Login
              </button>
              <button
                className={`toggle-btn ${!isLogin ? 'active' : ''}`}
                onClick={() => navigate('/signup')}
              >
                Signup
              </button>
            </div>

            <h2 className="form-title">Login Here</h2>

            {error && (
              <div className="error-message">
                <AlertCircle size={18} />
                <span>{error}</span>
              </div>
            )}

            <form onSubmit={handleSubmit}>
              {/* Email Field */}
              <div className="form-group">
                <label htmlFor="email">Email Address</label>
                <div className="input-wrapper">
                  <Mail size={18} className="input-icon" />
                  <input
                    id="email"
                    type="email"
                    placeholder="Email Address"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                  />
                </div>
              </div>

              {/* Password Field */}
              <div className="form-group">
                <label htmlFor="password">Password</label>
                <div className="input-wrapper">
                  <Lock size={18} className="input-icon" />
                  <input
                    id="password"
                    type={showPassword ? 'text' : 'password'}
                    placeholder="Password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                  />
                  <button
                    type="button"
                    className="password-toggle"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                  </button>
                </div>
              </div>

              {/* Remember Me & Forgot Password */}
              <div className="form-extras">
                <label className="checkbox-label">
                  <input
                    type="checkbox"
                    checked={rememberMe}
                    onChange={(e) => setRememberMe(e.target.checked)}
                  />
                  <span>Remember me</span>
                </label>
                <a href="#" className="forgot-link">Forgot password?</a>
              </div>

              {/* Submit Button */}
              <button type="submit" className="submit-btn" disabled={loading}>
                {loading ? 'Logging in...' : 'Login'}
              </button>
            </form>

            {/* Sign Up Link */}
            <div className="form-footer">
              Not a member? <a onClick={() => navigate('/signup')}>Signup now</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const authStyles = `
body, html {
  margin: 0;
  padding: 0;
  overflow-x: hidden; /* Prevent horizontal scroll */
}

  .auth-container {
  min-height: 100vh;
  width: 100vw; /* ADD THIS LINE */
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 20px;
  font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
}

  .auth-wrapper {
    display: grid;
    grid-template-columns: 1fr 1fr;
    max-width: 1200px;
    width: 100%;
    gap: 40px;
  }

  @media (max-width: 968px) {
    .auth-wrapper {
      grid-template-columns: 1fr;
    }
    .auth-branding {
      display: none;
    }
  }

  /* Branding Section */
  .auth-branding {
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
  }
    
.brand-logo {
  max-width: 200px;
  height: auto;
  margin-bottom: 16px;
}

.powered-by-logo {
  max-width: 150px;
  height: auto;
  margin-bottom: 1px;
  margin-top: 1px;
}
  .brand-content {
    text-align: center;
  }

  .brand-icon {
    width: 100px;
    height: 100px;
    margin: 0 auto 24px;
    background: rgba(255, 255, 255, 0.1);
    backdrop-filter: blur(10px);
    border-radius: 30px;
    display: flex;
    align-items: center;
    justify-content: center;
    border: 2px solid rgba(255, 255, 255, 0.2);
  }

  .brand-content h1 {
    font-size: 48px;
    font-weight: 700;
    margin-bottom: 8px;
  }

  .brand-content > p {
    font-size: 16px;
    opacity: 0.9;
    margin-bottom: 32px;
  }

  .brand-description {
    max-width: 400px;
    margin: 0 auto;
  }

  .brand-description p {
    font-size: 18px;
    line-height: 1.6;
    opacity: 0.95;
  }

  /* Form Container */
  .auth-form-container {
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .auth-card {
    background: #f5f7fb;
    padding: 48px 40px;
    border-radius: 30px;
    box-shadow: 20px 20px 60px rgba(0, 0, 0, 0.15), 
                -20px -20px 60px rgba(255, 255, 255, 0.7);
    width: 100%;
    max-width: 480px;
  }

  /* Toggle Buttons */
  .auth-toggle {
    display: flex;
    gap: 16px;
    margin-bottom: 32px;
  }

  .toggle-btn {
    flex: 1;
    padding: 14px 24px;
    border: none;
    background: #f5f7fb;
    color: #64748b;
    font-size: 16px;
    font-weight: 600;
    border-radius: 15px;
    cursor: pointer;
    transition: all 0.3s ease;
    box-shadow: 8px 8px 16px rgba(163, 177, 198, 0.3), 
                -8px -8px 16px rgba(255, 255, 255, 0.7);
  }

  .toggle-btn.active {
    background: linear-gradient(135deg, #667eea, #764ba2);
    color: white;
    box-shadow: inset 4px 4px 8px rgba(0, 0, 0, 0.2),
                inset -4px -4px 8px rgba(255, 255, 255, 0.1);
  }

  .toggle-btn:hover:not(.active) {
    transform: translateY(-2px);
  }

  /* Form Title */
  .form-title {
    font-size: 32px;
    font-weight: 700;
    color: #1e293b;
    margin-bottom: 24px;
    text-align: center;
  }

  /* Error Message */
  .error-message {
    background: rgba(239, 68, 68, 0.1);
    color: #dc2626;
    padding: 12px 16px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    gap: 8px;
    margin-bottom: 20px;
    font-size: 14px;
    border: 1px solid rgba(239, 68, 68, 0.2);
  }

  /* Form Groups */
  .form-group {
    margin-bottom: 24px;
  }

  .form-group label {
    display: block;
    font-size: 14px;
    font-weight: 600;
    color: #475569;
    margin-bottom: 8px;
  }

  .input-wrapper {
    position: relative;
    display: flex;
    align-items: center;
  }

  .input-icon {
    position: absolute;
    left: 16px;
    color: #94a3b8;
    pointer-events: none;
  }

  .input-wrapper input {
    width: 100%;
    padding: 14px 16px 14px 48px;
    border: none;
    background: #f5f7fb;
    border-radius: 15px;
    font-size: 15px;
    color: #1e293b;
    box-shadow: inset 6px 6px 12px rgba(163, 177, 198, 0.3),
                inset -6px -6px 12px rgba(255, 255, 255, 0.7);
    transition: all 0.3s ease;
  }

  .input-wrapper input:focus {
    outline: none;
    box-shadow: inset 6px 6px 12px rgba(163, 177, 198, 0.4),
                inset -6px -6px 12px rgba(255, 255, 255, 0.8),
                0 0 0 3px rgba(102, 126, 234, 0.1);
  }

  .input-wrapper input::placeholder {
    color: #cbd5e1;
  }

  .password-toggle {
    position: absolute;
    right: 16px;
    background: none;
    border: none;
    cursor: pointer;
    padding: 8px;
    color: #94a3b8;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: color 0.2s;
  }

  .password-toggle:hover {
    color: #667eea;
  }

  /* Form Extras */
  .form-extras {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 28px;
    font-size: 14px;
  }

  .checkbox-label {
    display: flex;
    align-items: center;
    gap: 8px;
    cursor: pointer;
    color: #475569;
  }

  .checkbox-label input[type="checkbox"] {
    width: 18px;
    height: 18px;
    cursor: pointer;
  }

  .forgot-link {
    color: #667eea;
    text-decoration: none;
    font-weight: 500;
    transition: color 0.2s;
  }

  .forgot-link:hover {
    color: #764ba2;
  }

  /* Submit Button */
  .submit-btn {
    width: 100%;
    padding: 16px;
    border: none;
    background: linear-gradient(135deg, #667eea, #764ba2);
    color: white;
    font-size: 16px;
    font-weight: 600;
    border-radius: 15px;
    cursor: pointer;
    transition: all 0.3s ease;
    box-shadow: 8px 8px 16px rgba(102, 126, 234, 0.3),
                -8px -8px 16px rgba(255, 255, 255, 0.1);
    margin-bottom: 24px;
  }

  .submit-btn:hover:not(:disabled) {
    transform: translateY(-2px);
    box-shadow: 10px 10px 20px rgba(102, 126, 234, 0.4),
                -10px -10px 20px rgba(255, 255, 255, 0.1);
  }

  .submit-btn:active:not(:disabled) {
    transform: translateY(0);
  }

  .submit-btn:disabled {
    opacity: 0.6;
    cursor: not-allowed;
  }

  /* Form Footer */
  .form-footer {
    text-align: center;
    color: #64748b;
    font-size: 14px;
  }

  .form-footer a {
    color: #667eea;
    text-decoration: none;
    font-weight: 600;
    cursor: pointer;
  }

  .form-footer a:hover {
    color: #764ba2;
  }
`;

export default SignIn;