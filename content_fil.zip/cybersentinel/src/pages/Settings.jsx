import React, { useState, useEffect } from 'react';
import { Shield, Save, RotateCcw, Download, AlertCircle, CheckCircle, Menu, X, Home, FileText, BarChart3, Settings as SettingsIcon, LogOut } from 'lucide-react';

// Mock signOut function
const signOut = () => {
  console.log('Signing out...');
};

const Settings = () => {
  // Get environment variables
  const BLOCKLIST_SERVER_URL = import.meta.env?.VITE_BLOCKLIST_SERVER_URL || 'http://192.168.1.189:8081';
  const BLOCKLIST_ENDPOINT = import.meta.env?.VITE_BLOCKLIST_ENDPOINT || '/url_blocklist.txt';
  const AUTO_REFRESH_INTERVAL = parseInt(import.meta.env?.VITE_AUTO_REFRESH_INTERVAL || '30000');
  const BLOCKLIST_URL = `${BLOCKLIST_SERVER_URL}${BLOCKLIST_ENDPOINT}`;

  const [darkMode, setDarkMode] = useState(true);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [blocklist, setBlocklist] = useState('');
  const [saveStatus, setSaveStatus] = useState(null);
  const [blocklistStats, setBlocklistStats] = useState({ total: 0, domains: 0, paths: 0, regex: 0 });
  const [isLoading, setIsLoading] = useState(false);
  const [fetchError, setFetchError] = useState(null);
  const [lastFetchTime, setLastFetchTime] = useState(null);
  
  // New states for search functionality
  const [searchUrl, setSearchUrl] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [actionStatus, setActionStatus] = useState(null);

  // Fetch blocklist from server
  const fetchBlocklist = async () => {
    setIsLoading(true);
    setFetchError(null);
    
    try {
      const response = await fetch(BLOCKLIST_URL, {
        method: 'GET',
        headers: {
          'Content-Type': 'text/plain',
        },
        mode: 'cors',
      });

      if (!response.ok) {
        throw new Error(`Server responded with status ${response.status}`);
      }

      const content = await response.text();
      setBlocklist(content);
      setLastFetchTime(new Date());
      console.log('✅ Blocklist fetched successfully');
    } catch (error) {
      console.error('❌ Failed to fetch blocklist:', error);
      setFetchError(error.message);
      setBlocklist('');
    } finally {
      setIsLoading(false);
    }
  };

  // Search for URL in blocklist (real-time)
  const handleSearch = (searchTerm = searchUrl) => {
    if (!searchTerm.trim()) {
      setSearchResults([]);
      return;
    }

    const lines = blocklist.split('\n');
    const results = [];
    
    lines.forEach((line, index) => {
      const trimmedLine = line.trim();
      const isBlocked = !trimmedLine.startsWith('#');
      const cleanUrl = trimmedLine.replace(/^#\s*/, '');
      
      if (cleanUrl.toLowerCase().includes(searchTerm.toLowerCase())) {
        results.push({
          lineNumber: index,
          url: cleanUrl,
          isBlocked: isBlocked,
          originalLine: line
        });
      }
    });

    setSearchResults(results);
  };

  // Real-time search as user types
  useEffect(() => {
    const debounceTimer = setTimeout(() => {
      if (searchUrl.trim()) {
        handleSearch(searchUrl);
      } else {
        setSearchResults([]);
      }
    }, 300);

    return () => clearTimeout(debounceTimer);
  }, [searchUrl, blocklist]);

  // Block URL - removes # prefix
  const handleBlock = async () => {
    if (!searchUrl.trim()) {
      setActionStatus({ type: 'error', message: 'Please enter a URL to block' });
      setTimeout(() => setActionStatus(null), 3000);
      return;
    }

    const lines = blocklist.split('\n');
    let modified = false;
    let foundUrl = false;

    const newLines = lines.map(line => {
      const trimmedLine = line.trim();
      const cleanUrl = trimmedLine.replace(/^#\s*/, '');
      
      if (cleanUrl.toLowerCase().includes(searchUrl.toLowerCase())) {
        foundUrl = true;
        if (trimmedLine.startsWith('#')) {
          modified = true;
          return cleanUrl; // Remove # to block
        }
      }
      return line;
    });

    // If URL not found, add it as blocked
    if (!foundUrl) {
      newLines.push(searchUrl.trim());
      modified = true;
    }

    if (modified) {
      const updatedBlocklist = newLines.join('\n');
      setBlocklist(updatedBlocklist);
      await saveBlocklistToServer(updatedBlocklist);
      setActionStatus({ type: 'success', message: '✅ URL blocked successfully!' });
      handleSearch(searchUrl); // Refresh search results
    } else {
      setActionStatus({ type: 'error', message: '⚠️ URL is already blocked' });
    }
    
    setTimeout(() => setActionStatus(null), 3000);
  };

  // Unblock URL - adds # prefix
  const handleUnblock = async () => {
    if (!searchUrl.trim()) {
      setActionStatus({ type: 'error', message: 'Please enter a URL to unblock' });
      setTimeout(() => setActionStatus(null), 3000);
      return;
    }

    const lines = blocklist.split('\n');
    let modified = false;

    const newLines = lines.map(line => {
      const trimmedLine = line.trim();
      const cleanUrl = trimmedLine.replace(/^#\s*/, '');
      
      if (cleanUrl.toLowerCase().includes(searchUrl.toLowerCase())) {
        if (!trimmedLine.startsWith('#') && trimmedLine.length > 0) {
          modified = true;
          return '# ' + trimmedLine; // Add # to unblock
        }
      }
      return line;
    });

    if (modified) {
      const updatedBlocklist = newLines.join('\n');
      setBlocklist(updatedBlocklist);
      await saveBlocklistToServer(updatedBlocklist);
      setActionStatus({ type: 'success', message: '✅ URL unblocked successfully!' });
      handleSearch(searchUrl); // Refresh search results
    } else {
      setActionStatus({ type: 'error', message: '⚠️ URL is already unblocked or not found' });
    }
    
    setTimeout(() => setActionStatus(null), 3000);
  };

  // Toggle individual result (block/unblock specific URL)
  const toggleResult = async (result) => {
    const lines = blocklist.split('\n');
    
    lines[result.lineNumber] = result.isBlocked 
      ? '# ' + result.url  // Unblock it
      : result.url;        // Block it
    
    const updatedBlocklist = lines.join('\n');
    setBlocklist(updatedBlocklist);
    await saveBlocklistToServer(updatedBlocklist);
    
    setActionStatus({ 
      type: 'success', 
      message: result.isBlocked ? '✅ URL unblocked!' : '✅ URL blocked!' 
    });
    setTimeout(() => setActionStatus(null), 2000);
  };

  // Save blocklist to server
  const saveBlocklistToServer = async (content) => {
    try {
      const response = await fetch(BLOCKLIST_URL, {
        method: 'PUT',
        headers: {
          'Content-Type': 'text/plain',
        },
        mode: 'cors',
        body: content,
      });

      if (!response.ok) {
        throw new Error(`Server responded with status ${response.status}`);
      }

      console.log('✅ Blocklist saved to server');
    } catch (error) {
      console.error('❌ Failed to save blocklist:', error);
      setActionStatus({ type: 'error', message: `Failed to save: ${error.message}` });
    }
  };

  // Export blocklist as text file
  const handleExport = () => {
    const blob = new Blob([blocklist], { type: 'text/plain' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `blocklist_${new Date().toISOString().split('T')[0]}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
    
    setActionStatus({ type: 'success', message: 'Blocklist exported successfully!' });
    setTimeout(() => setActionStatus(null), 3000);
  };

  const handleReset = () => {
    if (window.confirm('Are you sure you want to reload the blocklist from the server?')) {
      fetchBlocklist();
    }
  };

  // Initial fetch
  useEffect(() => {
    fetchBlocklist();
  }, []);

  // Auto-refresh
  useEffect(() => {
    const interval = setInterval(() => {
      fetchBlocklist();
    }, AUTO_REFRESH_INTERVAL);

    return () => clearInterval(interval);
  }, []);

  // Calculate stats
  useEffect(() => {
    const lines = blocklist.split('\n').filter(line => line.trim() && !line.trim().startsWith('#'));
    const domains = lines.filter(line => !line.includes('/') && !line.includes('*') && !line.startsWith('regex:') && !line.startsWith('vid:') && !line.startsWith('re:')).length;
    const paths = lines.filter(line => (line.includes('/') || line.includes('*')) && !line.startsWith('regex:') && !line.startsWith('re:')).length;
    const regex = lines.filter(line => line.startsWith('regex:') || line.startsWith('re:')).length;

    setBlocklistStats({
      total: lines.length,
      domains,
      paths,
      regex
    });
  }, [blocklist]);

  return (
    <div className={`app-wrapper ${darkMode ? 'dark-mode' : 'light-mode'}`}>
      <style>{settingsStyles}</style>

      {/* Sidebar */}
      <aside className={`sidebar ${sidebarOpen ? 'open' : 'closed'}`}>
        <div className="sidebar-header">
          <div className="logo-sidebar">
            <img src="/src/assets/cybersentinel.png" alt="CyberSentinel" className="brand-logo" />
            {sidebarOpen && <span>CyberSentinel</span>}
          </div>
          <button className="sidebar-toggle" onClick={() => setSidebarOpen(!sidebarOpen)}>
            {sidebarOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>

        <nav className="sidebar-nav">
          <button className="nav-item" onClick={() => window.location.href = '/dashboard'}>
            <Home size={20} />
            {sidebarOpen && <span>Dashboard</span>}
          </button>
          <button className="nav-item" onClick={() => window.location.href = '/dashboard'}>
            <FileText size={20} />
            {sidebarOpen && <span>Logs</span>}
          </button>
          <button className="nav-item" onClick={() => window.location.href = '/analytics'}>
            <BarChart3 size={20} />
            {sidebarOpen && <span>Analytics</span>}
          </button>
          <button className="nav-item active">
            <SettingsIcon size={20} />
            {sidebarOpen && <span>Settings</span>}
          </button>
        </nav>
      </aside>

      {/* Main Content */}
      <main className="main-content">
        <header className="header">
          <div className="header-left">
            <h1 className="page-title">Settings</h1>
            <p className="page-subtitle">Manage URL blocking rules</p>
          </div>
          <div className="header-actions">
            <button className="btn-export" onClick={handleExport}>
              <Download size={18} />
              Export
            </button>
          {/* <button className="btn-reset" onClick={handleReset}>
              <RotateCcw size={18} />
               Reset 
            </button> */}
            <button className="btn-icon" onClick={() => setDarkMode(!darkMode)}>
              {darkMode ? 'Light' : 'Dark'}
            </button>
            <button className="btn-icon" onClick={() => { signOut(); window.location.href = '/signin'; }}>
              <LogOut size={18} />
            </button>
          </div>
        </header>

        <div className="content-area">
          {/* Connection Status */}
          <div className="connection-status">
            <div className="status-item">
              <span className="status-label">Server:</span>
              <span className="status-value">{BLOCKLIST_SERVER_URL}</span>
            </div>
            {lastFetchTime && (
              <div className="status-item">
                <span className="status-label">Last Updated:</span>
                <span className="status-value">{lastFetchTime.toLocaleTimeString()}</span>
              </div>
            )}
            {isLoading && (
              <div className="status-item loading">
                <span>⟳ Loading...</span>
              </div>
            )}
          </div>

          {/* Error Alert */}
          {fetchError && (
            <div className="status-alert error">
              <AlertCircle size={18} />
              <div>
                <strong>Failed to fetch blocklist from server</strong>
                <p style={{ fontSize: '12px', marginTop: '4px', opacity: 0.8 }}>
                  Error: {fetchError}
                </p>
              </div>
              <button 
                className="btn-retry" 
                onClick={fetchBlocklist}
                disabled={isLoading}
              >
                Retry
              </button>
            </div>
          )}

          {/* Action Status Message */}
          {actionStatus && (
            <div className={`status-alert ${actionStatus.type}`}>
              {actionStatus.type === 'success' ? <CheckCircle size={18} /> : <AlertCircle size={18} />}
              <span>{actionStatus.message}</span>
            </div>
          )}

          {/* Stats Cards */}
          <div className="stats-grid">
            <div className="stat-card gradient-blue">
              <div className="stat-icon-wrapper"><Shield size={24} /></div>
              <div className="stat-content">
                <div className="stat-label">Total Rules</div>
                <div className="stat-value">{blocklistStats.total}</div>
              </div>
            </div>

            <div className="stat-card gradient-green">
              <div className="stat-icon-wrapper"><SettingsIcon size={24} /></div>
              <div className="stat-content">
                <div className="stat-label">Domain Rules</div>
                <div className="stat-value">{blocklistStats.domains}</div>
              </div>
            </div>

            <div className="stat-card gradient-purple">
              <div className="stat-icon-wrapper"><FileText size={24} /></div>
              <div className="stat-content">
                <div className="stat-label">Path Rules</div>
                <div className="stat-value">{blocklistStats.paths}</div>
              </div>
            </div>

            <div className="stat-card gradient-red">
              <div className="stat-icon-wrapper"><AlertCircle size={24} /></div>
              <div className="stat-content">
                <div className="stat-label">Regex Rules</div>
                <div className="stat-value">{blocklistStats.regex}</div>
              </div>
            </div>
          </div>

          {/* URL Management Section */}
          <div className="url-management-card">
            <div className="management-header">
              <h2>URL Management</h2>
              <p>Search, block, or unblock URLs from the blocklist</p>
            </div>

            {/* Search Bar */}
            <div className="search-section">
              <input
                type="text"
                className="search-input"
                placeholder="Enter URL to search (e.g., example.com, youtube.com/watch?v=...)"
                value={searchUrl}
                onChange={(e) => setSearchUrl(e.target.value)}
                onKeyPress={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                  }
                }}
                disabled={isLoading}
              />
              
              {/* Action Buttons */}
              <div className="action-buttons">
                <button 
                  className="btn-block" 
                  onClick={handleBlock}
                  disabled={isLoading || !searchUrl.trim()}
                >
                  Block
                </button>
                <button 
                  className="btn-unblock" 
                  onClick={handleUnblock}
                  disabled={isLoading || !searchUrl.trim()}
                >
                  Unblock
                </button>
                <button 
                  className="btn-search" 
                  onClick={() => {
                    if (searchResults.length > 0) {
                      setActionStatus({ type: 'success', message: `Found ${searchResults.length} matching URL(s)` });
                      setTimeout(() => setActionStatus(null), 3000);
                    } else if (searchUrl.trim()) {
                      setActionStatus({ type: 'error', message: 'No matching URLs found' });
                      setTimeout(() => setActionStatus(null), 3000);
                    }
                  }}
                  disabled={isLoading || !searchUrl.trim()}
                >
                  Search ({searchResults.length})
                </button>
              </div>
            </div>

            {/* Search Results */}
            {searchResults.length > 0 && (
              <div className="search-results">
                <h3>Search Results ({searchResults.length})</h3>
                <div className="results-list">
                  {searchResults.map((result, index) => (
                    <div key={index} className={`result-item ${result.isBlocked ? 'blocked' : 'unblocked'}`}>
                      <div className="result-url">{result.url}</div>
                      <div className="result-actions">
                        <div className="result-status">
                          {result.isBlocked ? (
                            <span className="status-blocked">🔴 Blocked</span>
                          ) : (
                            <span className="status-unblocked">🟢 Unblocked</span>
                          )}
                        </div>
                        <button 
                          className={`btn-toggle ${result.isBlocked ? 'btn-toggle-unblock' : 'btn-toggle-block'}`}
                          onClick={() => toggleResult(result)}
                          disabled={isLoading}
                        >
                          {result.isBlocked ? 'Unblock' : 'Block'}
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Usage Guide */}
            <div className="usage-guide">
              <h3>Usage Guide:</h3>
              <ul>
                <li><strong>Block:</strong> Removes # prefix from URL (activates blocking)</li>
                <li><strong>Unblock:</strong> Adds # prefix to URL (deactivates blocking)</li>
                <li><strong>Search:</strong> Find URLs in the blocklist</li>
                <li><strong>Export:</strong> Download the complete blocklist as a text file</li>
              </ul>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

const settingsStyles = `
* { margin: 0; padding: 0; box-sizing: border-box; }
body { font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; }

html, body, #root, .main-content {
  height: 100%;
  width: 100%;
}

:root {
  --light-bg: #eef3f7;
  --light-surface: #f5f7fb;
  --light-shadow-dark: rgba(16, 24, 40, 0.08);
  --light-shadow-light: rgba(255, 255, 255, 0.85);
  --light-text: #1e293b;
  --light-text-secondary: #64748b;
  --dark-bg: #0f1724;
  --dark-surface: #1a2332;
  --dark-shadow-dark: rgba(0, 0, 0, 0.3);
  --dark-shadow-light: rgba(255, 255, 255, 0.02);
  --dark-text: #f1f5f9;
  --dark-text-secondary: #94a3b8;
  --sidebar-width: 260px;
  --sidebar-collapsed: 70px;
}

.app-wrapper { display: flex; min-height: 100vh; transition: all 0.3s ease; width: 100%; }
.light-mode { background: var(--light-bg); color: var(--light-text); }
.dark-mode { background: var(--dark-bg); color: var(--dark-text); }

/* Sidebar */
.sidebar { width: var(--sidebar-width); position: fixed; left: 0; top: 0; bottom: 0; transition: all 0.3s ease; z-index: 100; display: flex; flex-direction: column; }
.sidebar.closed { width: var(--sidebar-collapsed); }
.light-mode .sidebar { background: var(--light-surface); box-shadow: 4px 0 20px var(--light-shadow-dark); }
.dark-mode .sidebar { background: var(--dark-surface); box-shadow: 4px 0 20px rgba(0, 0, 0, 0.3); }

.logo-sidebar {
  display: flex; align-items: center; gap: 12px; font-size: 18px; font-weight: 700;
  background: linear-gradient(135deg, #5EEAD4, #60A5FA);
  -webkit-background-clip: text; -webkit-text-fill-color: transparent;
  background-clip: text; width: auto;
}

.brand-logo {
  margin-top: 8px; max-width: 40px;height: auto;
}

.sidebar-header { padding: 24px 20px; display: flex; align-items: center; justify-content: space-between; border-bottom: 1px solid; width: 100%; }
.light-mode .sidebar-header { border-color: rgba(0, 0, 0, 0.06); }
.dark-mode .sidebar-header { border-color: rgba(255, 255, 255, 0.06); }

.sidebar-toggle { background: none; border: none; cursor: pointer; padding: 8px; border-radius: 8px; transition: all 0.2s; color: inherit; }
.sidebar-toggle:hover { background: rgba(94, 234, 212, 0.1); }

.sidebar-nav { padding: 20px 12px; display: flex; flex-direction: column; gap: 8px; width: 100%; }

.nav-item { display: flex; align-items: center; gap: 12px; padding: 12px 16px; border: none; background: none; color: inherit; cursor: pointer; border-radius: 12px; font-size: 15px; transition: all 0.2s; text-align: left; width: 100%; }
.nav-item:hover { background: rgba(94, 234, 212, 0.05); }
.nav-item.active { background: linear-gradient(135deg, #5EEAD4, #60A5FA); color: white; font-weight: 600; }
.sidebar.closed .nav-item { justify-content: center; }
.sidebar.closed .nav-item span { display: none; }

/* Main Content */
.main-content { flex: 1; margin-left: var(--sidebar-width); transition: margin-left 0.3s ease; width: 100%; }
.sidebar.closed + .main-content { margin-left: var(--sidebar-collapsed); }

.header { display: flex; justify-content: space-between; align-items: center; padding: 24px 32px; border-bottom: 1px solid; width: 100%; }
.light-mode .header { background: var(--light-surface); border-color: rgba(0, 0, 0, 0.06); }
.dark-mode .header { background: var(--dark-surface); border-color: rgba(255, 255, 255, 0.06); }

.header-left { flex: 1; }
.page-title { font-size: 28px; font-weight: 700; margin-bottom: 4px; }
.page-subtitle { font-size: 13px; opacity: 0.6; }

.header-actions { display: flex; gap: 12px; align-items: center; }

.btn-export { padding: 10px 16px; border: none; border-radius: 12px; font-size: 14px; font-weight: 600; cursor: pointer; display: flex; align-items: center; gap: 8px; background: rgba(94, 234, 212, 0.1); color: #5EEAD4; transition: all 0.2s; }
.btn-export:hover { background: rgba(94, 234, 212, 0.2); transform: translateY(-2px); }

.btn-reset { padding: 10px 16px; border: none; border-radius: 12px; font-size: 14px; font-weight: 600; cursor: pointer; display: flex; align-items: center; gap: 8px; background: rgba(239, 68, 68, 0.1); color: #ef4444; transition: all 0.2s; }
.btn-reset:hover { background: rgba(239, 68, 68, 0.2); transform: translateY(-2px); }

.btn-icon { padding: 10px; border: none; border-radius: 10px; cursor: pointer; transition: all 0.2s; display: flex; align-items: center; justify-content: center; background: none; color: inherit; }
.light-mode .btn-icon { background: rgba(0, 0, 0, 0.03); }
.dark-mode .btn-icon { background: rgba(255, 255, 255, 0.05); }
.btn-icon:hover { transform: translateY(-2px); }

.content-area { padding: 32px; width: 100%; max-width: 18000px; margin: 0 auto; box-sizing: border-box; }

/* Connection Status */
.connection-status { display: flex; align-items: center; gap: 20px; padding: 14px 20px; border-radius: 12px; margin-bottom: 24px; font-size: 13px; border: 1px solid rgba(94, 234, 212, 0.2); background: rgba(94, 234, 212, 0.05); width: 100%; flex-wrap: wrap; }
.status-item { display: flex; align-items: center; gap: 8px; }
.status-label { opacity: 0.7; font-weight: 500; }
.status-value { font-weight: 600; color: #5EEAD4; font-family: 'Monaco', monospace; }
.status-item.loading { animation: pulse 1.5s ease-in-out infinite; }
@keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.5; } }

/* Status Alert */
.status-alert { padding: 14px 20px; border-radius: 12px; display: flex; align-items: center; gap: 10px; margin-bottom: 24px; font-size: 14px; font-weight: 500; animation: slideIn 0.3s ease; width: 100%; }
.status-alert.success { background: rgba(16, 185, 129, 0.1); color: #059669; border: 1px solid rgba(16, 185, 129, 0.2); }
.status-alert.error { background: rgba(239, 68, 68, 0.1); color: #ef4444; border: 1px solid rgba(239, 68, 68, 0.2); flex-wrap: wrap; }
.btn-retry { padding: 6px 12px; border: 1px solid currentColor; border-radius: 6px; background: transparent; color: inherit; cursor: pointer; font-size: 12px; font-weight: 600; margin-left: auto; }
.btn-retry:hover { background: rgba(239, 68, 68, 0.1); }
.btn-retry:disabled { opacity: 0.5; cursor: not-allowed; }
@keyframes slideIn { from { opacity: 0; transform: translateY(-10px); } to { opacity: 1; transform: translateY(0); } }

/* Stats Grid */
.stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 20px; margin-bottom: 32px; width: 100%; }
.stat-card { padding: 20px; border-radius: 20px; display: flex; align-items: center; gap: 16px; transition: all 0.3s ease; }
.light-mode .stat-card { background: var(--light-surface); box-shadow: 8px 8px 18px var(--light-shadow-dark), -8px -8px 18px var(--light-shadow-light); }
.dark-mode .stat-card { background: var(--dark-surface); box-shadow: 8px 8px 18px var(--dark-shadow-dark), -8px -8px 18px var(--dark-shadow-light); }
.stat-card:hover { transform: translateY(-4px); }

.stat-icon-wrapper { width: 50px; height: 50px; border-radius: 12px; display: flex; align-items: center; justify-content: center; color: white; }
.gradient-blue .stat-icon-wrapper { background: linear-gradient(135deg, #5EEAD4, #60A5FA); }
.gradient-green .stat-icon-wrapper { background: linear-gradient(135deg, #10b981, #059669); }
.gradient-red .stat-icon-wrapper { background: linear-gradient(135deg, #ef4444, #dc2626); }
.gradient-purple .stat-icon-wrapper { background: linear-gradient(135deg, #A78BFA, #FB7185); }

.stat-content { flex: 1; }
.stat-label { font-size: 12px; opacity: 0.7; margin-bottom: 4px; text-transform: uppercase; letter-spacing: 0.5px; }
.stat-value { font-size: 28px; font-weight: 700; }

/* URL Management Card */
.url-management-card { padding: 32px; border-radius: 20px; width: 100%; }
.light-mode .url-management-card { background: var(--light-surface); box-shadow: 8px 8px 18px var(--light-shadow-dark), -8px -8px 18px var(--light-shadow-light); }
.dark-mode .url-management-card { background: var(--dark-surface); box-shadow: 8px 8px 18px var(--dark-shadow-dark), -8px -8px 18px var(--dark-shadow-light); }

.management-header { margin-bottom: 24px; }
.management-header h2 { font-size: 24px; font-weight: 600; margin-bottom: 8px; }
.management-header p { font-size: 14px; opacity: 0.7; }

/* Search Section */
.search-section { margin-bottom: 24px; }

.search-input { width: 100%; padding: 16px 20px; border: 2px solid rgba(94, 234, 212, 0.2); border-radius: 12px; font-size: 15px; background: transparent; color: inherit; transition: all 0.3s; margin-bottom: 16px; }
.search-input:focus { outline: none; border-color: #5EEAD4; box-shadow: 0 0 0 3px rgba(94, 234, 212, 0.1); }
.search-input::placeholder { opacity: 0.5; }
.search-input:disabled { opacity: 0.5; cursor: not-allowed; }
.light-mode .search-input { background: rgba(0, 0, 0, 0.02); }
.dark-mode .search-input { background: rgba(255, 255, 255, 0.03); }

/* Action Buttons */
.action-buttons { display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; }

.btn-block, .btn-unblock, .btn-search { padding: 14px 24px; border: none; border-radius: 12px; font-size: 15px; font-weight: 600; cursor: pointer; transition: all 0.2s; }

.btn-block { background: linear-gradient(135deg, #ef4444, #dc2626); color: white; }
.btn-block:hover:not(:disabled) { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(239, 68, 68, 0.4); }

.btn-unblock { background: linear-gradient(135deg, #10b981, #059669); color: white; }
.btn-unblock:hover:not(:disabled) { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(16, 185, 129, 0.4); }

.btn-search { background: linear-gradient(135deg, #5EEAD4, #60A5FA); color: white; }
.btn-search:hover:not(:disabled) { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(94, 234, 212, 0.4); }

.btn-block:disabled, .btn-unblock:disabled, .btn-search:disabled { opacity: 0.5; cursor: not-allowed; transform: none; }

/* Search Results */
.search-results { margin-top: 24px; padding: 20px; border-radius: 12px; background: rgba(94, 234, 212, 0.05); border: 1px solid rgba(94, 234, 212, 0.2); }

.search-results h3 { font-size: 16px; font-weight: 600; margin-bottom: 16px; color: #5EEAD4; }

.results-list { display: flex; flex-direction: column; gap: 12px; max-height: 400px; overflow-y: auto; }

.result-item { padding: 16px; border-radius: 10px; display: flex; justify-content: space-between; align-items: center; transition: all 0.2s; gap: 16px; }
.light-mode .result-item { background: rgba(0, 0, 0, 0.02); }
.dark-mode .result-item { background: rgba(255, 255, 255, 0.03); }
.result-item:hover { transform: translateX(4px); }
.light-mode .result-item:hover { background: rgba(0, 0, 0, 0.04); }
.dark-mode .result-item:hover { background: rgba(255, 255, 255, 0.05); }

.result-url { font-family: 'Monaco', monospace; font-size: 13px; word-break: break-all; flex: 1; padding-right: 16px; }

.result-actions { display: flex; align-items: center; gap: 12px; }

.result-status { white-space: nowrap; }
.status-blocked { color: #ef4444; font-weight: 600; font-size: 13px; }
.status-unblocked { color: #10b981; font-weight: 600; font-size: 13px; }

/* Toggle Buttons */
.btn-toggle { padding: 8px 16px; border: none; border-radius: 8px; font-size: 13px; font-weight: 600; cursor: pointer; transition: all 0.2s; white-space: nowrap; }
.btn-toggle:disabled { opacity: 0.5; cursor: not-allowed; }

.btn-toggle-block { background: rgba(239, 68, 68, 0.15); color: #ef4444; border: 1px solid rgba(239, 68, 68, 0.3); }
.btn-toggle-block:hover:not(:disabled) { background: rgba(239, 68, 68, 0.25); transform: translateY(-2px); }

.btn-toggle-unblock { background: rgba(16, 185, 129, 0.15); color: #10b981; border: 1px solid rgba(16, 185, 129, 0.3); }
.btn-toggle-unblock:hover:not(:disabled) { background: rgba(16, 185, 129, 0.25); transform: translateY(-2px); }

/* Usage Guide */
.usage-guide { margin-top: 24px; padding: 20px; border-radius: 12px; background: rgba(102, 126, 234, 0.05); border: 1px solid rgba(102, 126, 234, 0.2); }

.usage-guide h3 { font-size: 16px; font-weight: 600; margin-bottom: 12px; }

.usage-guide ul { list-style: none; display: flex; flex-direction: column; gap: 8px; }

.usage-guide li { font-size: 14px; padding: 8px 0; border-bottom: 1px solid rgba(255, 255, 255, 0.05); }
.usage-guide li:last-child { border-bottom: none; }

.usage-guide strong { color: #5EEAD4; font-weight: 600; }

/* Responsive Design */
@media (max-width: 768px) {
  .sidebar { width: var(--sidebar-collapsed); }
  .sidebar .nav-item span { display: none; }
  .main-content { margin-left: var(--sidebar-collapsed); }
  .content-area { padding: 20px; }
  .stats-grid { grid-template-columns: 1fr; }
  .action-buttons { grid-template-columns: 1fr; }
  .header-actions { flex-wrap: wrap; }
}

@media (max-width: 480px) {
  .page-title { font-size: 22px; }
  .stat-value { font-size: 24px; }
  .url-management-card { padding: 20px; }
}
`;

export default Settings;