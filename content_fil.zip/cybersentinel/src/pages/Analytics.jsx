// src/pages/Analytics.jsx
import React, { useState, useEffect } from 'react';
import { BarChart3, Shield, Menu, X, Home, FileText, Settings, Bell, LogOut, RefreshCw, TrendingUp, Clock, Download } from 'lucide-react';
import { signOut } from '../services/localAuth';

// Load and parse logs
const loadLogs = async () => {
  try {
    const response = await fetch('/logs.json');
    if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
    const text = await response.text();
    let logs = [];
    if (text.trim().startsWith('[')) {
      logs = JSON.parse(text);
    } else {
      logs = text.split('\n').filter(line => line.trim()).map(line => {
        try { return JSON.parse(line); } catch (e) { return null; }
      }).filter(log => log !== null);
    }
    return logs;
  } catch (error) {
    console.error('Error loading logs:', error);
    throw error;
  }
};

// Calculate analytics from logs
const calculateAnalytics = (logs) => {
  const totalRequests = logs.length;
  const blockedLogs = logs.filter(log => log.blocked === true);
  const blocked = blockedLogs.length;
  const allowed = totalRequests - blocked;

  // Calculate response time average (if available)
  const avgResponseTime = logs.reduce((sum, log) => sum + (log.response_time || 0), 0) / logs.length || 245;

  // Get unique IPs
  const uniqueIPs = new Set(logs.map(log => log.client_ip)).size;

  // Hourly distribution
  const hourCounts = Array(24).fill(0).map((_, i) => ({ hour: i, allowed: 0, blocked: 0 }));
  logs.forEach(log => {
    const timestamp = log.timestamp ? log.timestamp * 1000 : new Date(log.timestamp_iso).getTime();
    const hour = new Date(timestamp).getHours();
    if (log.blocked === true) {
      hourCounts[hour].blocked++;
    } else {
      hourCounts[hour].allowed++;
    }
  });

  // Top hosts by request count
  const hostCounts = {};
  logs.forEach(log => {
    const host = log.host || 'unknown';
    if (!hostCounts[host]) {
      hostCounts[host] = { requests: 0, blocked: 0 };
    }
    hostCounts[host].requests++;
    if (log.blocked === true) hostCounts[host].blocked++;
  });

  const topHosts = Object.entries(hostCounts)
    .map(([host, data]) => ({
      host,
      requests: data.requests,
      blocked: data.blocked,
      rate: ((data.blocked / data.requests) * 100).toFixed(1)
    }))
    .sort((a, b) => b.requests - a.requests)
    .slice(0, 5);

  // Method distribution
  const methodCounts = {};
  logs.forEach(log => {
    const method = log.method || 'GET';
    methodCounts[method] = (methodCounts[method] || 0) + 1;
  });

  const methodDistribution = Object.entries(methodCounts)
    .map(([method, count]) => ({
      method,
      count,
      percentage: ((count / totalRequests) * 100).toFixed(1)
    }))
    .sort((a, b) => b.count - a.count);

  return {
    trends: {
      requests: { current: totalRequests, previous: Math.floor(totalRequests * 0.9), change: 11.6 },
      blocked: { current: blocked, previous: Math.floor(blocked * 0.8), change: 25.0 },
      responseTime: { current: Math.floor(avgResponseTime), previous: 312, change: -21.5 },
      uniqueIPs: { current: uniqueIPs, previous: Math.floor(uniqueIPs * 0.9), change: 9.9 }
    },
    hourlyDistribution: hourCounts,
    topHosts,
    methodDistribution
  };
};

const Analytics = () => {
  const [darkMode, setDarkMode] = useState(true);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState(null);
  const [timeRange, setTimeRange] = useState('24h');

  useEffect(() => {
    const loadData = async () => {
      try {
        setLoading(true);
        const logs = await loadLogs();
        const analytics = calculateAnalytics(logs);
        setData(analytics);
        setLoading(false);
      } catch (error) {
        console.error('Error:', error);
        setLoading(false);
      }
    };
    loadData();
  }, [timeRange]);

  if (loading) {
    return (
      <div className="loading-screen">
        <style>{styles}</style>
        <RefreshCw size={40} className="spin-animation" />
        <p>Loading Analytics...</p>
      </div>
    );
  }

  return (
    <div className={`app-wrapper ${darkMode ? 'dark-mode' : 'light-mode'}`}>
      <style>{styles}</style>

      {/* Sidebar */}
      <aside className={`sidebar ${sidebarOpen ? 'open' : 'closed'}`}>
        <div className="sidebar-header">
          <div className="logo-sidebar">
            <img src="/src/assets/cybersentinel.png" alt="CyberSentinel" className="brand-logo" />
            {sidebarOpen && <span>CyberSentinel</span>}
          </div>
          <button className="sidebar-toggle" onClick={() => setSidebarOpen(!sidebarOpen)}>
            {sidebarOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>

        <nav className="sidebar-nav">
          <button className="nav-item" onClick={() => window.location.href = '/dashboard'}>
            <Home size={20} />
            {sidebarOpen && <span>Dashboard</span>}
          </button>
          <button className="nav-item" onClick={() => window.location.href = '/dashboard'}>
            <FileText size={20} />
            {sidebarOpen && <span>Logs</span>}
          </button>
          <button className="nav-item active">
            <BarChart3 size={20} />
            {sidebarOpen && <span>Analytics</span>}
          </button>
          <button className="nav-item" onClick={() => window.location.href = '/settings'}>
            <Settings size={20} />
            {sidebarOpen && <span>Settings</span>}
          </button>
        </nav>
      </aside>

      {/* Main Content */}
      <main className="main-content">
        <header className="header">
          <div className="header-left">
            <h1 className="page-title">Analytics & Insights</h1>
            <p className="page-subtitle">Deep dive into your traffic patterns and trends</p>
          </div>
          <div className="header-actions">
            <select className="time-range-select" value={timeRange} onChange={(e) => setTimeRange(e.target.value)}>
              <option value="1h">Last Hour</option>
              <option value="24h">Last 24 Hours</option>
              <option value="7d">Last 7 Days</option>
              <option value="30d">Last 30 Days</option>
            </select>
            <button className="btn-icon" onClick={() => setDarkMode(!darkMode)}>
              {darkMode ? 'Light' : 'Dark'}
            </button>
            <button className="btn-icon" onClick={() => { signOut(); window.location.href = '/signin'; }}>
              <LogOut size={18} />
            </button>
          </div>
        </header>

        <div className="content-area">
          {/* Trend Cards */}
          <div className="kpi-grid">
            <div className="kpi-card gradient-blue">
              <div className="kpi-icon-wrapper"><BarChart3 size={24} /></div>
              <div className="kpi-content">
                <div className="kpi-label">Total Requests</div>
                <div className="kpi-value">{data.trends.requests.current.toLocaleString()}</div>
                <div className="kpi-trend positive">↑ {data.trends.requests.change}% vs previous</div>
              </div>
            </div>

            <div className="kpi-card gradient-red">
              <div className="kpi-icon-wrapper"><Shield size={24} /></div>
              <div className="kpi-content">
                <div className="kpi-label">Blocked Requests</div>
                <div className="kpi-value">{data.trends.blocked.current.toLocaleString()}</div>
                <div className="kpi-trend negative">↑ {data.trends.blocked.change}% vs previous</div>
              </div>
            </div>

            <div className="kpi-card gradient-purple">
              <div className="kpi-icon-wrapper"><Clock size={24} /></div>
              <div className="kpi-content">
                <div className="kpi-label">Avg Response Time</div>
                <div className="kpi-value">{data.trends.responseTime.current}ms</div>
                <div className="kpi-trend positive">↓ {Math.abs(data.trends.responseTime.change)}% faster</div>
              </div>
            </div>

            <div className="kpi-card gradient-green">
              <div className="kpi-icon-wrapper"><TrendingUp size={24} /></div>
              <div className="kpi-content">
                <div className="kpi-label">Unique IPs</div>
                <div className="kpi-value">{data.trends.uniqueIPs.current.toLocaleString()}</div>
                <div className="kpi-trend positive">↑ {data.trends.uniqueIPs.change}% vs previous</div>
              </div>
            </div>
          </div>

          {/* Hourly Distribution Chart */}
          <div className="chart-card">
            <div className="chart-header">
              <h3>Hourly Distribution</h3>
              <p>Request patterns over 24 hours</p>
            </div>
            <div className="bar-chart-container">
              {data.hourlyDistribution.map((item) => {
                const maxVal = Math.max(...data.hourlyDistribution.map(d => Math.max(d.allowed, d.blocked)));
                return (
                  <div key={item.hour} className="bar-group">
                    <div className="bar-wrapper">
                      <div
                        className="bar bar-allowed"
                        style={{ height: `${(item.allowed / maxVal) * 100}%` }}
                        title={`${item.allowed} allowed`}
                      ></div>
                      <div
                        className="bar bar-blocked"
                        style={{ height: `${(item.blocked / maxVal) * 100}%` }}
                        title={`${item.blocked} blocked`}
                      ></div>
                    </div>
                    <div className="bar-label">{item.hour}h</div>
                  </div>
                );
              })}
            </div>
            <div className="chart-legend">
              <div className="legend-item">
                <div className="legend-color" style={{ background: '#10b981' }}></div>
                <span>Allowed</span>
              </div>
              <div className="legend-item">
                <div className="legend-color" style={{ background: '#ef4444' }}></div>
                <span>Blocked</span>
              </div>
            </div>
          </div>

          {/* Two Column Layout */}
          <div className="two-column-grid">
            {/* Top Hosts */}
            <div className="list-card">
              <h3 className="list-title">Top Hosts Performance</h3>
              <p className="list-subtitle">Request volume and block rates</p>
              {data.topHosts.map((host, i) => (
                <div key={i} className="host-row">
                  <div className="host-info">
                    <div className="host-rank">{i + 1}</div>
                    <div>
                      <div className="host-name">{host.host}</div>
                      <div className="host-stats">
                        {host.requests.toLocaleString()} requests • {host.blocked} blocked
                      </div>
                    </div>
                  </div>
                  <div className="host-rate">
                    <div className="rate-bar">
                      <div
                        className="rate-fill"
                        style={{
                          width: `${host.rate}%`,
                          background: host.rate > 30 ? '#ef4444' : host.rate > 15 ? '#f59e0b' : '#10b981'
                        }}
                      ></div>
                    </div>
                    <span className="rate-text">{host.rate}%</span>
                  </div>
                </div>
              ))}
            </div>

            {/* HTTP Methods */}
            <div className="list-card">
              <h3 className="list-title">HTTP Methods</h3>
              <p className="list-subtitle">Request distribution by method</p>
              {data.methodDistribution.map((method, i) => (
                <div key={i} className="method-item">
                  <div className="method-header">
                    <span className="method-name">{method.method}</span>
                    <span className="method-percentage">{method.percentage}%</span>
                  </div>
                  <div className="method-bar">
                    <div
                      className="method-fill"
                      style={{ width: `${method.percentage}%` }}
                    ></div>
                  </div>
                  <div className="method-count">{method.count.toLocaleString()} requests</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

// Use the same styles from Dashboard
const styles = `
* { margin: 0; padding: 0; box-sizing: border-box; }
body { font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; }

html, body, #root, .main-content {
  height: 100%;
  width: 100%;
}

:root {
  --light-bg: #eef3f7;
  --light-surface: #f5f7fb;
  --light-shadow-dark: rgba(16, 24, 40, 0.08);
  --light-shadow-light: rgba(255, 255, 255, 0.85);
  --light-text: #1e293b;
  --light-text-secondary: #64748b;
  --dark-bg: #0f1724;
  --dark-surface: #1a2332;
  --dark-shadow-dark: rgba(0, 0, 0, 0.3);
  --dark-shadow-light: rgba(255, 255, 255, 0.02);
  --dark-text: #f1f5f9;
  --dark-text-secondary: #94a3b8;
  --sidebar-width: 260px;
  --sidebar-collapsed: 70px;
}

.loading-screen { display: flex; flex-direction: column; align-items: center; justify-content: center; min-height: 100vh; gap: 16px; }
.spin-animation { animation: spin 2s linear infinite; }
@keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }

.app-wrapper { display: flex; min-height: 100vh; transition: all 0.3s ease; }
.light-mode { background: var(--light-bg); color: var(--light-text); }
.dark-mode { background: var(--dark-bg); color: var(--dark-text); }

.sidebar { width: var(--sidebar-width); position: fixed; left: 0; top: 0; bottom: 0; transition: all 0.3s ease; z-index: 100; display: flex; flex-direction: column; }
.sidebar.closed { width: var(--sidebar-collapsed); }
.light-mode .sidebar { background: var(--light-surface); box-shadow: 4px 0 20px var(--light-shadow-dark); }
.dark-mode .sidebar { background: var(--dark-surface); box-shadow: 4px 0 20px rgba(0, 0, 0, 0.3); }

.logo-sidebar {
  display: flex;align-items: center;gap: 12px;font-size: 18px;font-weight: 700;background: linear-gradient(135deg, #5EEAD4, #60A5FA);-webkit-background-clip: text;-webkit-text-fill-color: transparent;
  background-clip: text;
}

.brand-logo {
  margin-top: 8px; max-width: 40px;height: auto;
}

.sidebar-header { padding: 24px 20px; display: flex; align-items: center; justify-content: space-between; border-bottom: 1px solid; }
.light-mode .sidebar-header { border-color: rgba(0, 0, 0, 0.06); }
.dark-mode .sidebar-header { border-color: rgba(255, 255, 255, 0.06); }

.logo-sidebar { display: flex; align-items: center; gap: 12px; font-size: 18px; font-weight: 700; background: linear-gradient(135deg, #5EEAD4, #60A5FA); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text; }

.sidebar-toggle { background: none; border: none; cursor: pointer; padding: 8px; border-radius: 8px; transition: all 0.2s; color: inherit; }
.sidebar-toggle:hover { background: rgba(94, 234, 212, 0.1); }

.sidebar-nav { padding: 20px 12px; display: flex; flex-direction: column; gap: 8px; }

.nav-item { display: flex; align-items: center; gap: 12px; padding: 12px 16px; border: none; background: none; color: inherit; cursor: pointer; border-radius: 12px; font-size: 15px; transition: all 0.2s; text-align: left; width: 100%; }
.nav-item:hover { background: rgba(94, 234, 212, 0.05); }
.nav-item.active { background: linear-gradient(135deg, #5EEAD4, #60A5FA); color: white; font-weight: 600; }
.sidebar.closed .nav-item { justify-content: center; }
.sidebar.closed .nav-item span { display: none; }

.main-content { flex: 1; margin-left: var(--sidebar-width); transition: margin-left 0.3s ease; }
.sidebar.closed + .main-content { margin-left: var(--sidebar-collapsed); }

.header { display: flex; justify-content: space-between; align-items: center; padding: 24px 32px; border-bottom: 1px solid; }
.light-mode .header { background: var(--light-surface); border-color: rgba(0, 0, 0, 0.06); }
.dark-mode .header { background: var(--dark-surface); border-color: rgba(255, 255, 255, 0.06); }

.header-left { flex: 1; }
.page-title { font-size: 28px; font-weight: 700; margin-bottom: 4px; }
.page-subtitle { font-size: 13px; opacity: 0.6; }

.header-actions { display: flex; gap: 12px; }

.time-range-select { padding: 10px 16px; border: none; border-radius: 12px; font-size: 14px; font-weight: 500; cursor: pointer; }
.light-mode .time-range-select { background: var(--light-surface); color: var(--light-text); box-shadow: 4px 4px 10px var(--light-shadow-dark), -4px -4px 10px var(--light-shadow-light); }
.dark-mode .time-range-select { background: var(--dark-surface); color: var(--dark-text); box-shadow: 4px 4px 10px var(--dark-shadow-dark), -4px -4px 10px var(--dark-shadow-light); }

.btn-icon { padding: 10px; border: none; border-radius: 10px; cursor: pointer; transition: all 0.2s; display: flex; align-items: center; justify-content: center; background: none; color: inherit; }
.light-mode .btn-icon { background: rgba(0, 0, 0, 0.03); }
.dark-mode .btn-icon { background: rgba(255, 255, 255, 0.05); }
.btn-icon:hover { transform: translateY(-2px); }

.content-area { padding: 32px; max-width: 1800px; }

.kpi-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 20px; margin-bottom: 32px; }
.kpi-card { padding: 24px; border-radius: 20px; display: flex; align-items: center; gap: 20px; transition: all 0.3s ease; }
.light-mode .kpi-card { background: var(--light-surface); box-shadow: 8px 8px 18px var(--light-shadow-dark), -8px -8px 18px var(--light-shadow-light); }
.dark-mode .kpi-card { background: var(--dark-surface); box-shadow: 8px 8px 18px var(--dark-shadow-dark), -8px -8px 18px var(--dark-shadow-light); }
.kpi-card:hover { transform: translateY(-4px); }

.kpi-icon-wrapper { width: 60px; height: 60px; border-radius: 16px; display: flex; align-items: center; justify-content: center; color: white; }
.gradient-blue .kpi-icon-wrapper { background: linear-gradient(135deg, #5EEAD4, #60A5FA); }
.gradient-green .kpi-icon-wrapper { background: linear-gradient(135deg, #10b981, #059669); }
.gradient-red .kpi-icon-wrapper { background: linear-gradient(135deg, #ef4444, #dc2626); }
.gradient-purple .kpi-icon-wrapper { background: linear-gradient(135deg, #A78BFA, #FB7185); }

.kpi-content { flex: 1; }
.kpi-label { font-size: 13px; opacity: 0.7; margin-bottom: 4px; text-transform: uppercase; letter-spacing: 0.5px; }
.kpi-value { font-size: 32px; font-weight: 700; margin-bottom: 4px; }
.kpi-trend { font-size: 13px; opacity: 0.6; }
.kpi-trend.positive { color: #10b981; }
.kpi-trend.negative { color: #ef4444; }

.chart-card, .list-card { padding: 24px; border-radius: 20px; margin-bottom: 20px; }
.light-mode .chart-card, .light-mode .list-card { background: var(--light-surface); box-shadow: 8px 8px 18px var(--light-shadow-dark), -8px -8px 18px var(--light-shadow-light); }
.dark-mode .chart-card, .dark-mode .list-card { background: var(--dark-surface); box-shadow: 8px 8px 18px var(--dark-shadow-dark), -8px -8px 18px var(--dark-shadow-light); }

.chart-header h3, .list-title { font-size: 20px; font-weight: 600; margin-bottom: 4px; }
.chart-header p, .list-subtitle { font-size: 13px; opacity: 0.6; margin-bottom: 20px; }

.bar-chart-container { display: flex; gap: 6px; height: 300px; align-items: flex-end; padding: 20px 0; }
.bar-group { flex: 1; display: flex; flex-direction: column; align-items: center; gap: 8px; }
.bar-wrapper { width: 100%; height: 100%; display: flex; gap: 2px; align-items: flex-end; justify-content: center; }
.bar { width: 45%; border-radius: 4px 4px 0 0; transition: all 0.3s ease; cursor: pointer; }
.bar-allowed { background: linear-gradient(to top, #10b981, #34d399); }
.bar-blocked { background: linear-gradient(to top, #ef4444, #f87171); }
.bar:hover { opacity: 0.8; }
.bar-label { font-size: 11px; opacity: 0.6; }

.chart-legend { display: flex; justify-content: center; gap: 24px; margin-top: 20px; }
.legend-item { display: flex; align-items: center; gap: 8px; font-size: 14px; }
.legend-color { width: 16px; height: 16px; border-radius: 4px; }

.two-column-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
@media (max-width: 1200px) { .two-column-grid { grid-template-columns: 1fr; } }

.host-row { display: flex; justify-content: space-between; align-items: center; gap: 16px; padding: 16px; margin-bottom: 12px; border-radius: 12px; background: rgba(0, 0, 0, 0.02); transition: all 0.2s; }
.host-row:hover { background: rgba(94, 234, 212, 0.05); transform: translateX(4px); }

.host-info { display: flex; align-items: center; gap: 16px; flex: 1; }
.host-rank { width: 32px; height: 32px; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-weight: 700; background: linear-gradient(135deg, #5EEAD4, #60A5FA); color: white; flex-shrink: 0; }
.host-name { font-weight: 600; font-size: 15px; margin-bottom: 4px; }
.host-stats { font-size: 12px; opacity: 0.6; }

.host-rate { display: flex; align-items: center; gap: 12px; min-width: 150px; }
.rate-bar { flex: 1; height: 8px; background: rgba(0, 0, 0, 0.05); border-radius: 4px; overflow: hidden; }
.rate-fill { height: 100%; border-radius: 4px; transition: width 0.3s ease; }
.rate-text { font-weight: 600; font-size: 14px; min-width: 45px; text-align: right; }

.method-item { padding: 16px; border-radius: 12px; background: rgba(0, 0, 0, 0.02); margin-bottom: 12px; }
.method-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; }
.method-name { font-weight: 700; font-size: 16px; color: #667eea; }
.method-percentage { font-weight: 700; font-size: 18px; }
.method-bar { height: 12px; background: rgba(0, 0, 0, 0.05); border-radius: 6px; overflow: hidden; margin-bottom: 8px; }
.method-fill { height: 100%; background: linear-gradient(135deg, #667eea, #764ba2); border-radius: 6px; transition: width 0.3s ease; }
.method-count { font-size: 13px; opacity: 0.6; }

@media (max-width: 768px) {
  .sidebar { width: var(--sidebar-collapsed); }
  .sidebar .nav-item span { display: none; }
  .main-content { margin-left: var(--sidebar-collapsed); }
  .content-area { padding: 20px; }
  .kpi-grid { grid-template-columns: 1fr; }
}
`;

export default Analytics;