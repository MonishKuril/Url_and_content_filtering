import React, { useState, useEffect } from 'react';
import { BarChart3, Shield, AlertTriangle, TrendingUp, Globe, Activity, RefreshCw, Menu, X, FileText, PieChart, Settings, Bell, Home, Filter, Search, Download } from 'lucide-react';
import { signOut } from '../services/localAuth';
import { LogOut } from 'lucide-react';
// ========== LOGS PARSER FUNCTIONS ==========
const loadLogs = async () => {
  try {
    console.log('📂 Loading logs from /logs.json...');
    const response = await fetch('/logs.json');
    if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);

    const text = await response.text();
    let logs = [];

    if (text.trim().startsWith('[')) {
      logs = JSON.parse(text);
    } else {
      logs = text.split('\n').filter(line => line.trim()).map(line => {
        try { return JSON.parse(line); } catch (e) { return null; }
      }).filter(log => log !== null);
    }

    console.log(`✅ Successfully loaded ${logs.length} log entries`);
    return logs;
  } catch (error) {
    console.error('❌ Error loading logs:', error);
    throw error;
  }
};

const calculateKPIs = (logs) => {
  const totalRequests = logs.length;

  // Get blocked count from counters_snapshot instead of event field
  const counters = getCounterSnapshot(logs);
  const blocked = (counters.blocked_watch || 0) +
    (counters.blocked_api || 0) +
    (counters.blocked_cdn_referer || 0) +
    (counters.blocked_host || 0) +
    (counters.blocked_prefix || 0) +
    (counters.blocked_regex || 0);

  const allowed = counters.allowed || logs.filter(log => log.event === 'allowed').length;

  const blockedPercentage = totalRequests > 0 ? ((blocked / totalRequests) * 100).toFixed(1) : 0;
  const allowedPercentage = totalRequests > 0 ? ((allowed / totalRequests) * 100).toFixed(1) : 0;

  return {
    totalRequests,
    allowed,
    blocked,
    blockedPercentage: parseFloat(blockedPercentage),
    allowedPercentage: parseFloat(allowedPercentage)
  };
};

const getCounterSnapshot = (logs) => {
  if (logs.length === 0) return { blocked_watch: 0, blocked_api: 0, blocked_cdn_referer: 0, blocked_host: 0, blocked_prefix: 0, blocked_regex: 0, allowed: 0 };
  const logWithCounters = [...logs].reverse().find(log => log.counters_snapshot);
  return logWithCounters?.counters_snapshot || { blocked_watch: 0, blocked_api: 0, blocked_cdn_referer: 0, blocked_host: 0, blocked_prefix: 0, blocked_regex: 0, allowed: 0 };
};

const generateTimeSeries = (logs, intervals = 20) => {
  if (logs.length === 0) return [];

  const timestamps = logs.map(log =>
    log.timestamp ? log.timestamp * 1000 : new Date(log.timestamp_iso).getTime()
  );
  const minTime = Math.min(...timestamps);
  const maxTime = Math.max(...timestamps);
  const timeRange = maxTime - minTime;
  const intervalMs = timeRange / intervals;

  const buckets = [];

  for (let i = 0; i < intervals; i++) {
    const startTime = minTime + (i * intervalMs);
    buckets.push({
      time: new Date(startTime).toLocaleTimeString('en-US', {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
      }),
      timestamp: startTime,
      allowed: 0,
      blocked: 0,
    });
  }

  logs.forEach(log => {
    const logTime = log.timestamp ? log.timestamp * 1000 : new Date(log.timestamp_iso).getTime();
    const bucketIndex = Math.floor((logTime - minTime) / intervalMs);

    if (bucketIndex >= 0 && bucketIndex < intervals) {
      // Check if this request was blocked
      const isBlocked = log.blocked === true ||
        (log.block_reason && log.block_reason !== null && log.block_reason !== '-') ||
        log.event === 'blocked';

      if (isBlocked) {
        buckets[bucketIndex].blocked++;
      } else {
        buckets[bucketIndex].allowed++;
      }
    }
  });

  return buckets;
};
const getBlockReasons = (logs) => {
  const blockedLogs = logs.filter(log => log.event === 'blocked');
  const reasonCounts = {};

  blockedLogs.forEach(log => {
    const reason = log.block_reason || 'unknown';
    reasonCounts[reason] = (reasonCounts[reason] || 0) + 1;
  });

  const colors = { api: '#60A5FA', watch: '#A78BFA', regex: '#FB7185', host: '#5EEAD4', prefix: '#FCD34D', cdn_referer: '#F472B6', unknown: '#94A3B8' };

  return Object.entries(reasonCounts).map(([name, value]) => ({
    name: name.replace(/_/g, ' ').toUpperCase(),
    value,
    color: colors[name] || '#94A3B8',
  }));
};

const getTopBlockedUrls = (logs, limit = 10) => {
  // Filter using the same logic as other functions
  const blockedLogs = logs.filter(log =>
    log.blocked === true ||
    (log.block_reason && log.block_reason !== null && log.block_reason !== '-')
  );

  console.log('Blocked logs found:', blockedLogs.length); // Debug line

  const urlCounts = {};
  blockedLogs.forEach(log => {
    const url = log.url || log.path || 'unknown';
    urlCounts[url] = (urlCounts[url] || 0) + 1;
  });

  return Object.entries(urlCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, limit)
    .map(([url, count]) => ({ url, count }));
};

const extractYouTubeVideoId = (url, host) => {
  if (!host || (!host.includes('youtube') && !host.includes('youtu.be'))) return null;
  const match = url?.match(/[?&]v=([^&]+)/);
  if (match) return match[1];
  const shortMatch = url?.match(/youtu\.be\/([^?]+)/);
  if (shortMatch) return shortMatch[1];
  return null;
};

const getTopBlockedVideos = (logs, limit = 10) => {
  // Filter using same blocked logic
  const blockedLogs = logs.filter(log =>
    log.blocked === true ||
    (log.block_reason && log.block_reason !== null && log.block_reason !== '-')
  );

  const videoCounts = {};

  blockedLogs.forEach(log => {
    const videoId = extractYouTubeVideoId(log.url || '', log.host || '');
    if (videoId) {
      videoCounts[videoId] = (videoCounts[videoId] || 0) + 1;
    }
  });

  console.log('YouTube videos blocked:', Object.keys(videoCounts).length); // Debug line

  return Object.entries(videoCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, limit)
    .map(([videoId, count]) => ({ videoId, count }));
};

const getTopAllowedHosts = (logs, limit = 10) => {
  const allowedLogs = logs.filter(log => log.event === 'allowed');
  const hostCounts = {};
  allowedLogs.forEach(log => {
    const host = log.host || 'unknown';
    hostCounts[host] = (hostCounts[host] || 0) + 1;
  });
  return Object.entries(hostCounts).sort((a, b) => b[1] - a[1]).slice(0, limit).map(([host, count]) => ({ host, count }));
};

const getTopClientIPs = (logs, limit = 10) => {
  const ipCounts = {};
  logs.forEach(log => {
    const ip = log.client_ip || 'unknown';
    ipCounts[ip] = (ipCounts[ip] || 0) + 1;
  });
  return Object.entries(ipCounts).sort((a, b) => b[1] - a[1]).slice(0, limit).map(([ip, count]) => ({ ip, count }));
};

const getRecentLogs = (logs, limit = 20) => {
  return [...logs].sort((a, b) => {
    const timeA = a.timestamp ? a.timestamp * 1000 : new Date(a.timestamp_iso).getTime();
    const timeB = b.timestamp ? b.timestamp * 1000 : new Date(b.timestamp_iso).getTime();
    return timeB - timeA;
  }).slice(0, limit).map((log, index) => ({
    id: index + 1,
    timestamp: log.timestamp_iso || new Date(log.timestamp * 1000).toISOString(),
    host: log.host || 'unknown',
    url: log.url || log.path || '/',
    event: log.event || 'unknown',
    reason: log.block_reason || '-',
    ip: log.client_ip || 'unknown',
    method: log.method || 'GET',
    fullData: log,
  }));
};

// ========== MAIN DASHBOARD COMPONENT ==========
const Dashboard = () => {
  const [darkMode, setDarkMode] = useState(true);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [data, setData] = useState(null);
  const [selectedLog, setSelectedLog] = useState(null);
  const [activeSection, setActiveSection] = useState('dashboard');
  const [searchTerm, setSearchTerm] = useState('');
  const [filterEvent, setFilterEvent] = useState('all');


  const loadDashboardData = async () => {
    try {
      setLoading(true);
      setError(null);

      const logs = await loadLogs();

      const dashboardData = {
        kpis: calculateKPIs(logs),
        counters: getCounterSnapshot(logs),
        timeSeries: generateTimeSeries(logs, 20),
        blockReasons: getBlockReasons(logs),
        topBlockedUrls: getTopBlockedUrls(logs, 10),
        topBlockedVideos: getTopBlockedVideos(logs, 10),
        topAllowedHosts: getTopAllowedHosts(logs, 10),
        topIPs: getTopClientIPs(logs, 10),
        recentLogs: getRecentLogs(logs, 50),
        allLogs: logs,
        totalLogs: logs.length,
      };

      setData(dashboardData);
      setLoading(false);
    } catch (err) {
      setError(err.message);
      setLoading(false);
    }
  };

  useEffect(() => {
    loadDashboardData();
    if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
      setDarkMode(true);
    }
  }, []);

  const filteredLogs = data?.recentLogs.filter(log => {
    const matchesSearch = log.host.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.url.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.ip.includes(searchTerm);
    const matchesFilter = filterEvent === 'all' || log.event === filterEvent;
    return matchesSearch && matchesFilter;
  });

  if (loading) {
    return (
      <div className={`min-h-screen flex items-center justify-center ${darkMode ? 'bg-dark' : 'bg-light'}`}>
        <style>{styles}</style>
        <div className="loading-pulse">
          <RefreshCw size={40} className="spin-animation" />
          <p style={{ marginTop: '16px', fontSize: '18px' }}>Loading CyberSentinel...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className={`min-h-screen flex items-center justify-center ${darkMode ? 'bg-dark' : 'bg-light'}`}>
        <style>{styles}</style>
        <div className="error-container">
          <AlertTriangle size={60} color="#ef4444" />
          <h2 style={{ marginTop: '16px', fontSize: '24px', fontWeight: '600' }}>Error Loading Logs</h2>
          <p style={{ marginTop: '8px', opacity: 0.7 }}>{error}</p>
          <p style={{ marginTop: '16px', fontSize: '14px' }}>Make sure logs.json is in the public folder</p>
          <button className="btn-primary" style={{ marginTop: '24px' }} onClick={loadDashboardData}>
            <RefreshCw size={16} /> Retry
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className={`app-wrapper ${darkMode ? 'dark-mode' : 'light-mode'}`}>
      <style>{styles}</style>

      {/* Sidebar */}
      <aside className={`sidebar ${sidebarOpen ? 'open' : 'closed'}`}>
        <div className="sidebar-header">
          <div className="logo-sidebar">
            <img src="/src/assets/cybersentinel.png" alt="CyberSentinel" className="brand-logo" />
            {sidebarOpen && <span>CyberSentinel</span>}
          </div>
          <button className="sidebar-toggle" onClick={() => setSidebarOpen(!sidebarOpen)}>
            {sidebarOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>

        <nav className="sidebar-nav">
          <button
            className={`nav-item ${activeSection === 'dashboard' ? 'active' : ''}`}
            onClick={() => setActiveSection('dashboard')}
          >
            <Home size={20} />
            {sidebarOpen && <span>Dashboard</span>}
          </button>
          <button
            className={`nav-item ${activeSection === 'logs' ? 'active' : ''}`}
            onClick={() => setActiveSection('logs')}
          >
            <FileText size={20} />
            {sidebarOpen && <span>Logs</span>}
          </button>
        <button
            className="nav-item"
            onClick={() => window.location.href = '/analytics'}
          >
            <BarChart3 size={20} />
            {sidebarOpen && <span>Analytics</span>}
          </button>
          <button
            className="nav-item"
            onClick={() => window.location.href = '/settings'}
          >
            <Settings size={20} />
            {sidebarOpen && <span>Settings</span>}
          </button>
        </nav>
      </aside>

      {/* Main Content */}
      <main className="main-content">
        {/* Header */}
        <header className="header">
          <div className="header-left">
            <h1 className="page-title">
              {activeSection === 'dashboard' && 'Dashboard Overview'}
              {activeSection === 'logs' && 'Request Logs'}
              {activeSection === 'analytics' && 'Analytics & Insights'}
              {activeSection === 'settings' && 'Settings'}
              {activeSection === 'alerts' && 'Alerts & Notifications'}
            </h1>
            <p className="page-subtitle">powered by Virtual Galaxy • {data.totalLogs} logs loaded</p>
          </div>
          <div className="header-actions">
            <button className="btn-icon" onClick={loadDashboardData} title="Refresh Data">
              <RefreshCw size={18} />
            </button>
            <button className="btn-icon" onClick={() => setDarkMode(!darkMode)}>
              {darkMode ? 'Light' : 'Dark'}
            </button>
            {/* Add Logout Button */}
            <button className="btn-icon" onClick={() => {
              signOut();
              window.location.href = '/signin';
            }} title="Logout">
              <LogOut size={18} />
            </button>
          </div>
        </header>

        {/* Dashboard Section */}
        {activeSection === 'dashboard' && (
          <div className="content-area">
            {/* KPI Cards */}
            <div className="kpi-grid">
              <div className="kpi-card gradient-blue">
                <div className="kpi-icon-wrapper">
                  <Activity size={24} />
                </div>
                <div className="kpi-content">
                  <div className="kpi-label">Total Requests</div>
                  <div className="kpi-value">{data.kpis.totalRequests.toLocaleString()}</div>
                  <div className="kpi-trend">All tracked requests</div>
                </div>
              </div>

              <div className="kpi-card gradient-green">
                <div className="kpi-icon-wrapper">
                  <Shield size={24} />
                </div>
                <div className="kpi-content">
                  <div className="kpi-label">Allowed</div>
                  <div className="kpi-value">{data.kpis.allowed.toLocaleString()}</div>
                  <div className="kpi-trend positive">{data.kpis.allowedPercentage}% of total</div>
                </div>
              </div>

              <div className="kpi-card gradient-red">
                <div className="kpi-icon-wrapper">
                  <AlertTriangle size={24} />
                </div>
                <div className="kpi-content">
                  <div className="kpi-label">Blocked</div>
                  <div className="kpi-value">{data.kpis.blocked.toLocaleString()}</div>
                  <div className="kpi-trend negative">{data.kpis.blockedPercentage}% of total</div>
                </div>
              </div>

              <div className="kpi-card gradient-purple">
                <div className="kpi-icon-wrapper">
                  <TrendingUp size={24} />
                </div>
                <div className="kpi-content">
                  <div className="kpi-label">Block Rate</div>
                  <div className="kpi-value">{data.kpis.blockedPercentage}%</div>
                  <div className="kpi-trend">Security ratio</div>
                </div>
              </div>
            </div>

            {/* Counter Snapshots */}
            <div className="section-header">
              <h2>Counters Snapshot</h2>
            </div>
            <div className="counters-grid">
              {Object.entries(data.counters).map(([key, value]) => (
                <div key={key} className="counter-card">
                  <div className="counter-label">{key.replace(/_/g, ' ')}</div>
                  <div className="counter-value">{value.toLocaleString()}</div>
                </div>
              ))}
            </div>

            {/* Charts Section */}
            <div className="charts-row">
              <div className="chart-card large">
                <div className="chart-header">
                  <h3><Activity size={20} /> Traffic Overview - Real Time Data</h3>
                </div>
                <div className="chart-body">
                  <LineChart data={data.timeSeries} />
                </div>
              </div>

              <div className="chart-card">
                <div className="chart-header">
                  <h3><PieChart size={20} /> Block Reasons</h3>
                </div>
                <div className="chart-body">
                  {data.blockReasons.length > 0 ? (
                    <>
                      <PieChartComponent data={data.blockReasons} />
                      <div className="pie-legend">
                        {data.blockReasons.map((reason, i) => (
                          <div key={i} className="legend-item">
                            <div className="legend-color" style={{ background: reason.color }}></div>
                            <span className="legend-label">{reason.name}</span>
                            <strong>{reason.value}</strong>
                          </div>
                        ))}
                      </div>
                    </>
                  ) : (
                    <div className="empty-state">No blocked requests</div>
                  )}
                </div>
              </div>
            </div>

            {/* Lists Grid */}
            <div className="lists-grid">
              <div className="list-card">
                <h3 className="list-title">
                  <AlertTriangle size={18} /> Top Blocked URLs
                </h3>
                {data.topBlockedUrls.length > 0 ? data.topBlockedUrls.map((item, i) => (
                  <div key={i} className="list-item">
                    <span className="list-text" title={item.url}>{item.url}</span>
                    <span className="list-badge">{item.count}</span>
                  </div>
                )) : <div className="empty-state-small">No data</div>}
              </div>

              <div className="list-card">
                <h3 className="list-title">
                  <Activity size={18} /> Top Blocked Videos
                </h3>
                {data.topBlockedVideos.length > 0 ? data.topBlockedVideos.map((item, i) => (
                  <div key={i} className="list-item">
                    <span className="list-text">{item.videoId}</span>
                    <span className="list-badge">{item.count}</span>
                  </div>
                )) : <div className="empty-state-small">No YouTube blocks</div>}
              </div>

              <div className="list-card">
                <h3 className="list-title">
                  <Shield size={18} /> Top Allowed Hosts
                </h3>
                {data.topAllowedHosts.map((item, i) => (
                  <div key={i} className="list-item">
                    <span className="list-text">{item.host}</span>
                    <span className="list-badge success">{item.count}</span>
                  </div>
                ))}
              </div>

              <div className="list-card">
                <h3 className="list-title">
                  <Globe size={18} /> Top Client IPs
                </h3>
                {data.topIPs.map((item, i) => (
                  <div key={i} className="list-item">
                    <span className="list-text">
                      <Globe size={14} style={{ marginRight: '8px', verticalAlign: 'middle' }} />
                      {item.ip}
                    </span>
                    <span className="list-badge">{item.count}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Recent Logs Preview */}
            <div className="table-card">
              <div className="table-header">
                <h3>Recent Logs</h3>
                <button className="btn-secondary btn-sm" onClick={() => setActiveSection('logs')}>
                  View All Logs →
                </button>
              </div>
              <LogsTable logs={data.recentLogs.slice(0, 10)} onRowClick={setSelectedLog} />
            </div>
          </div>
        )}

        {/* Logs Section */}
        {activeSection === 'logs' && (
          <div className="content-area">
            <div className="filters-bar">
              <div className="search-box">
                <Search size={18} />
                <input
                  type="text"
                  placeholder="Search by host, URL, or IP..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              <select className="filter-select" value={filterEvent} onChange={(e) => setFilterEvent(e.target.value)}>
                <option value="all">All Events</option>
                <option value="allowed">Allowed</option>
                <option value="blocked">Blocked</option>
              </select>
              <button className="btn-secondary btn-sm">
                <Download size={16} /> Export CSV
              </button>
            </div>
            <div className="table-card">
              <LogsTable logs={filteredLogs || []} onRowClick={setSelectedLog} showPagination />
            </div>
          </div>
        )}

      </main>

      {/* Log Detail Modal */}
      {selectedLog && (
        <div className="modal-overlay" onClick={() => setSelectedLog(null)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h3>Log Details</h3>
              <button className="modal-close" onClick={() => setSelectedLog(null)}>×</button>
            </div>
            <div className="modal-body">
              <div className="detail-row">
                <strong>Timestamp:</strong>
                <span>{new Date(selectedLog.timestamp).toLocaleString()}</span>
              </div>
              <div className="detail-row">
                <strong>Host:</strong>
                <span>{selectedLog.host}</span>
              </div>
              <div className="detail-row">
                <strong>URL:</strong>
                <span>{selectedLog.url}</span>
              </div>
              <div className="detail-row">
                <strong>Method:</strong>
                <span>{selectedLog.method}</span>
              </div>
              <div className="detail-row">
                <strong>Event:</strong>
                <span className={`event-badge event-${selectedLog.event}`}>{selectedLog.event}</span>
              </div>
              <div className="detail-row">
                <strong>Block Reason:</strong>
                <span>{selectedLog.reason}</span>
              </div>
              <div className="detail-row">
                <strong>Client IP:</strong>
                <span>{selectedLog.ip}</span>
              </div>

              <div style={{ marginTop: '24px' }}>
                <strong>Full JSON:</strong>
                <pre className="json-pre">{JSON.stringify(selectedLog.fullData, null, 2)}</pre>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// ========== CHART COMPONENTS ==========
const LineChart = ({ data }) => {
  const [hoveredPoint, setHoveredPoint] = React.useState(null);
  const maxValue = Math.max(...data.map(d => Math.max(d.allowed, d.blocked)), 1);
  const chartHeight = 280;
  const chartWidth = 1000;
  const padding = { top: 20, right: 40, bottom: 40, left: 60 };
  const graphHeight = chartHeight - padding.top - padding.bottom;
  const graphWidth = chartWidth - padding.left - padding.right;

  return (
    <div style={{ position: 'relative', width: '100%', height: '320px' }}>
      {/* Legend */}
      <div style={{
        display: 'flex',
        justifyContent: 'center',
        gap: '24px',
        marginBottom: '16px',
        fontSize: '14px'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <div style={{
            width: '20px',
            height: '3px',
            background: '#10b981',
            borderRadius: '2px'
          }}></div>
          <span style={{ fontWeight: 500 }}>Allowed Requests</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <div style={{
            width: '20px',
            height: '3px',
            background: '#ef4444',
            borderRadius: '2px'
          }}></div>
          <span style={{ fontWeight: 500 }}>Blocked Requests</span>
        </div>
      </div>

      <svg
        viewBox={`0 0 ${chartWidth} ${chartHeight}`}
        preserveAspectRatio="xMidYMid meet"
        style={{ width: '100%', height: '280px' }}
        onMouseLeave={() => setHoveredPoint(null)}
      >
        <defs>
          <linearGradient id="allowedGradient" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" style={{ stopColor: '#10b981', stopOpacity: 0.3 }} />
            <stop offset="100%" style={{ stopColor: '#10b981', stopOpacity: 0 }} />
          </linearGradient>
          <linearGradient id="blockedGradient" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" style={{ stopColor: '#ef4444', stopOpacity: 0.3 }} />
            <stop offset="100%" style={{ stopColor: '#ef4444', stopOpacity: 0 }} />
          </linearGradient>
        </defs>

        {/* Y-axis labels */}
        {[0, 1, 2, 3, 4].map(i => {
          const value = Math.round((maxValue / 4) * (4 - i));
          const y = padding.top + (i * graphHeight / 4);
          return (
            <g key={i}>
              <line
                x1={padding.left}
                y1={y}
                x2={chartWidth - padding.right}
                y2={y}
                stroke="currentColor"
                strokeOpacity="0.1"
                strokeWidth="1"
              />
              <text
                x={padding.left - 10}
                y={y + 4}
                textAnchor="end"
                fontSize="11"
                fill="currentColor"
                opacity="0.6"
              >
                {value}
              </text>
            </g>
          );
        })}

        {/* X-axis labels (show every 4th label to avoid crowding) */}
        {data.filter((_, i) => i % 4 === 0).map((d, i) => {
          const actualIndex = i * 4;
          const x = padding.left + (actualIndex * graphWidth / (data.length - 1));
          return (
            <text
              key={actualIndex}
              x={x}
              y={chartHeight - padding.bottom + 20}
              textAnchor="middle"
              fontSize="11"
              fill="currentColor"
              opacity="0.6"
            >
              {d.time}
            </text>
          );
        })}

        {/* Axis labels */}
        <text
          x={padding.left - 45}
          y={chartHeight / 2}
          textAnchor="middle"
          fontSize="12"
          fill="currentColor"
          opacity="0.5"
          transform={`rotate(-90, ${padding.left - 45}, ${chartHeight / 2})`}
        >
          Number of Requests
        </text>

        <text
          x={chartWidth / 2}
          y={chartHeight - 5}
          textAnchor="middle"
          fontSize="12"
          fill="currentColor"
          opacity="0.5"
        >
          Time
        </text>

        {/* Allowed area */}
        <path
          d={`M ${padding.left} ${padding.top + graphHeight - (data[0].allowed / maxValue * graphHeight)} ${data.map((d, i) =>
            `L ${padding.left + (i * graphWidth) / (data.length - 1)} ${padding.top + graphHeight - (d.allowed / maxValue * graphHeight)}`
          ).join(' ')} L ${chartWidth - padding.right} ${padding.top + graphHeight} L ${padding.left} ${padding.top + graphHeight} Z`}
          fill="url(#allowedGradient)"
        />

        {/* Blocked area */}
        <path
          d={`M ${padding.left} ${padding.top + graphHeight - (data[0].blocked / maxValue * graphHeight)} ${data.map((d, i) =>
            `L ${padding.left + (i * graphWidth) / (data.length - 1)} ${padding.top + graphHeight - (d.blocked / maxValue * graphHeight)}`
          ).join(' ')} L ${chartWidth - padding.right} ${padding.top + graphHeight} L ${padding.left} ${padding.top + graphHeight} Z`}
          fill="url(#blockedGradient)"
        />

        {/* Allowed line */}
        <path
          d={`M ${padding.left} ${padding.top + graphHeight - (data[0].allowed / maxValue * graphHeight)} ${data.map((d, i) =>
            `L ${padding.left + (i * graphWidth) / (data.length - 1)} ${padding.top + graphHeight - (d.allowed / maxValue * graphHeight)}`
          ).join(' ')}`}
          stroke="#10b981"
          strokeWidth="3"
          fill="none"
        />

        {/* Blocked line */}
        <path
          d={`M ${padding.left} ${padding.top + graphHeight - (data[0].blocked / maxValue * graphHeight)} ${data.map((d, i) =>
            `L ${padding.left + (i * graphWidth) / (data.length - 1)} ${padding.top + graphHeight - (d.blocked / maxValue * graphHeight)}`
          ).join(' ')}`}
          stroke="#ef4444"
          strokeWidth="3"
          fill="none"
        />

        {/* Interactive hover points */}
        {data.map((d, i) => {
          const x = padding.left + (i * graphWidth) / (data.length - 1);
          const yAllowed = padding.top + graphHeight - (d.allowed / maxValue * graphHeight);
          const yBlocked = padding.top + graphHeight - (d.blocked / maxValue * graphHeight);

          return (
            <g key={i}>
              {/* Invisible larger hit area for easier hovering */}
              <rect
                x={x - 15}
                y={padding.top}
                width={30}
                height={graphHeight}
                fill="transparent"
                style={{ cursor: 'pointer' }}
                onMouseEnter={() => setHoveredPoint(i)}
              />

              {/* Show dots on hover */}
              {hoveredPoint === i && (
                <>
                  <circle cx={x} cy={yAllowed} r="5" fill="#10b981" stroke="white" strokeWidth="2" />
                  <circle cx={x} cy={yBlocked} r="5" fill="#ef4444" stroke="white" strokeWidth="2" />

                  {/* Vertical line on hover */}
                  <line
                    x1={x}
                    y1={padding.top}
                    x2={x}
                    y2={padding.top + graphHeight}
                    stroke="currentColor"
                    strokeOpacity="0.2"
                    strokeWidth="1"
                    strokeDasharray="4,4"
                  />
                </>
              )}
            </g>
          );
        })}
      </svg>

      {/* Hover tooltip */}
      {hoveredPoint !== null && (
        <div style={{
          position: 'absolute',
          top: '60px',
          left: `${((hoveredPoint / (data.length - 1)) * 100)}%`,
          transform: 'translateX(-50%)',
          background: 'rgba(0, 0, 0, 0.9)',
          color: 'white',
          padding: '12px 16px',
          borderRadius: '10px',
          fontSize: '13px',
          pointerEvents: 'none',
          zIndex: 10,
          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.3)',
          minWidth: '160px'
        }}>
          <div style={{ fontWeight: 600, marginBottom: '8px', borderBottom: '1px solid rgba(255,255,255,0.2)', paddingBottom: '6px' }}>
            {data[hoveredPoint].time}
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px' }}>
            <span style={{ color: '#10b981' }}>✓ Allowed:</span>
            <strong>{data[hoveredPoint].allowed}</strong>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
            <span style={{ color: '#ef4444' }}>✗ Blocked:</span>
            <strong>{data[hoveredPoint].blocked}</strong>
          </div>
          <div style={{ marginTop: '6px', paddingTop: '6px', borderTop: '1px solid rgba(255,255,255,0.2)', fontSize: '12px', opacity: 0.8 }}>
            Total: {data[hoveredPoint].allowed + data[hoveredPoint].blocked}
          </div>
        </div>
      )}
    </div>
  );
};
const PieChartComponent = ({ data }) => {
  const total = data.reduce((sum, r) => sum + r.value, 0);
  if (total === 0) return null;

  let currentAngle = -90;

  return (
    <svg viewBox="0 0 200 200" style={{ maxHeight: '200px', margin: '0 auto', display: 'block' }}>
      <defs>
        {data.map((reason, i) => (
          <radialGradient key={i} id={`pieGrad${i}`}>
            <stop offset="0%" style={{ stopColor: reason.color, stopOpacity: 1 }} />
            <stop offset="100%" style={{ stopColor: reason.color, stopOpacity: 0.7 }} />
          </radialGradient>
        ))}
      </defs>
      {data.map((reason, i) => {
        const percentage = (reason.value / total) * 360;
        const startAngle = currentAngle;
        currentAngle += percentage;
        const endAngle = currentAngle;

        const startRad = (startAngle * Math.PI) / 180;
        const endRad = (endAngle * Math.PI) / 180;

        const x1 = 100 + 80 * Math.cos(startRad);
        const y1 = 100 + 80 * Math.sin(startRad);
        const x2 = 100 + 80 * Math.cos(endRad);
        const y2 = 100 + 80 * Math.sin(endRad);

        const largeArc = percentage > 180 ? 1 : 0;

        return (
          <path
            key={i}
            d={`M 100 100 L ${x1} ${y1} A 80 80 0 ${largeArc} 1 ${x2} ${y2} Z`}
            fill={`url(#pieGrad${i})`}
          />
        );
      })}
    </svg>
  );
};

const LogsTable = ({ logs, onRowClick, showPagination }) => {
  return (
    <div className="table-wrapper">
      <table className="logs-table">
        <thead>
          <tr>
            <th>Timestamp</th>
            <th>Host</th>
            <th>URL</th>
            <th>Method</th>
            <th>Event</th>
            <th>Reason</th>
            <th>Client IP</th>
          </tr>
        </thead>
        <tbody>
          {logs.map((log) => (
            <tr key={log.id} onClick={() => onRowClick(log)}>
              <td>{new Date(log.timestamp).toLocaleString()}</td>
              <td>{log.host}</td>
              <td className="url-cell" title={log.url}>{log.url}</td>
              <td><span className="method-badge">{log.method}</span></td>
              <td>
                <span className={`event-badge event-${log.event}`}>
                  {log.event}
                </span>
              </td>
              <td>{log.reason}</td>
              <td>{log.ip}</td>
            </tr>
          ))}
        </tbody>
      </table>
      {logs.length === 0 && (
        <div className="empty-state">
          <FileText size={40} opacity={0.3} />
          <p>No logs found matching your filters</p>
        </div>
      )}
    </div>
  );
};

// ========== STYLES ==========
const styles = `
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
  overflow-x: hidden;
}

html, body, #root, .main-content {
  height: 100%;
  width: 100%;
}

:root {
  --light-bg: #eef3f7;
  --light-surface: #f5f7fb;
  --light-shadow-dark: rgba(16, 24, 40, 0.08);
  --light-shadow-light: rgba(255, 255, 255, 0.85);
  --light-text: #1e293b;
  --light-text-secondary: #64748b;
  
  --dark-bg: #0f1724;
  --dark-surface: #1a2332;
  --dark-shadow-dark: rgba(0, 0, 0, 0.3);
  --dark-shadow-light: rgba(255, 255, 255, 0.02);
  --dark-text: #f1f5f9;
  --dark-text-secondary: #94a3b8;
  
  --sidebar-width: 260px;
  --sidebar-collapsed: 70px;
}

.app-wrapper {
  display: flex;
  min-height: 100vh;
  transition: all 0.3s ease;
}

.light-mode {
  background: var(--light-bg);
  color: var(--light-text);
}

.dark-mode {
  background: var(--dark-bg);
  color: var(--dark-text);
}

/* Sidebar */
.sidebar {
  width: var(--sidebar-width);
  position: fixed;
  left: 0;
  top: 0;
  bottom: 0;
  transition: all 0.3s ease;
  z-index: 100;
  display: flex;
  flex-direction: column;
}

.sidebar.closed {
  width: var(--sidebar-collapsed);
}

.light-mode .sidebar {
  background: var(--light-surface);
  box-shadow: 4px 0 20px var(--light-shadow-dark);
}

.dark-mode .sidebar {
  background: var(--dark-surface);
  box-shadow: 4px 0 20px rgba(0, 0, 0, 0.3);
}

.sidebar-header {
  padding: 24px 20px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  border-bottom: 1px solid;
}

.light-mode .sidebar-header {
  border-color: rgba(0, 0, 0, 0.06);
}

.dark-mode .sidebar-header {
  border-color: rgba(255, 255, 255, 0.06);
}

.logo-sidebar {
  display: flex;
  align-items: center;
  gap: 12px;
  font-size: 18px;
  font-weight: 700;
  background: linear-gradient(135deg, #5EEAD4, #60A5FA);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

.sidebar-toggle {
  background: none;
  border: none;
  cursor: pointer;
  padding: 8px;
  border-radius: 8px;
  transition: all 0.2s;
  color: inherit;
}

.sidebar-toggle:hover {
  background: rgba(94, 234, 212, 0.1);
}

.sidebar-nav {
  padding: 20px 12px;
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.brand-logo {
  margin-top: 8px;
  max-width: 40px;
  height: auto;
}

.nav-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 12px 16px;
  border: none;
  background: none;
  color: inherit;
  cursor: pointer;
  border-radius: 12px;
  font-size: 15px;
  transition: all 0.2s;
  text-align: left;
  width: 100%;
}

.nav-item:hover {
  background: rgba(94, 234, 212, 0.05);
}

.nav-item.active {
  background: linear-gradient(135deg, #5EEAD4, #60A5FA);
  color: white;
  font-weight: 600;
}

.sidebar.closed .nav-item {
  justify-content: center;
}

.sidebar.closed .nav-item span {
  display: none;
}

/* Main Content */
.main-content {
  flex: 1;
  margin-left: var(--sidebar-width);
  transition: margin-left 0.3s ease;
}

.sidebar.closed + .main-content {
  margin-left: var(--sidebar-collapsed);
}

.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 24px 32px;
  border-bottom: 1px solid;
}

.light-mode .header {
  background: var(--light-surface);
  border-color: rgba(0, 0, 0, 0.06);
}

.dark-mode .header {
  background: var(--dark-surface);
  border-color: rgba(255, 255, 255, 0.06);
}

.header-left {
  flex: 1;
}

.page-title {
  font-size: 28px;
  font-weight: 700;
  margin-bottom: 4px;
}

.page-subtitle {
  font-size: 13px;
  opacity: 0.6;
}

.header-actions {
  display: flex;
  gap: 12px;
}

.btn-icon {
  padding: 10px;
  border: none;
  border-radius: 10px;
  cursor: pointer;
  transition: all 0.2s;
  display: flex;
  align-items: center;
  justify-content: center;
  background: none;
  color: inherit;
}

.light-mode .btn-icon {
  background: rgba(0, 0, 0, 0.03);
}

.dark-mode .btn-icon {
  background: rgba(255, 255, 255, 0.05);
}

.btn-icon:hover {
  transform: translateY(-2px);
}

.btn-primary {
  padding: 10px 20px;
  border: none;
  border-radius: 10px;
  cursor: pointer;
  font-weight: 600;
  background: linear-gradient(135deg, #5EEAD4, #60A5FA);
  color: white;
  display: flex;
  align-items: center;
  gap: 8px;
  transition: all 0.2s;
}

.btn-primary:hover {
  transform: translateY(-2px);
}

.btn-secondary {
  padding: 10px 20px;
  border: none;
  border-radius: 10px;
  cursor: pointer;
  font-weight: 500;
  display: flex;
  align-items: center;
  gap: 8px;
  transition: all 0.2s;
}

.light-mode .btn-secondary {
  background: var(--light-surface);
  color: var(--light-text);
  box-shadow: 4px 4px 10px var(--light-shadow-dark), -4px -4px 10px var(--light-shadow-light);
}

.dark-mode .btn-secondary {
  background: var(--dark-surface);
  color: var(--dark-text);
  box-shadow: 4px 4px 10px var(--dark-shadow-dark), -4px -4px 10px var(--dark-shadow-light);
}

.btn-secondary:hover {
  transform: translateY(-2px);
}

.btn-sm {
  padding: 8px 16px;
  font-size: 14px;
}

/* Content Area */
.content-area {
  padding: 32px;
  max-width: 1800px;
}

/* KPI Cards */
.kpi-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
  gap: 20px;
  margin-bottom: 32px;
}

.kpi-card {
  padding: 24px;
  border-radius: 20px;
  display: flex;
  align-items: center;
  gap: 20px;
  transition: all 0.3s ease;
}

.light-mode .kpi-card {
  background: var(--light-surface);
  box-shadow: 8px 8px 18px var(--light-shadow-dark), -8px -8px 18px var(--light-shadow-light);
}

.dark-mode .kpi-card {
  background: var(--dark-surface);
  box-shadow: 8px 8px 18px var(--dark-shadow-dark), -8px -8px 18px var(--dark-shadow-light);
}

.kpi-card:hover {
  transform: translateY(-4px);
}

.kpi-icon-wrapper {
  width: 60px;
  height: 60px;
  border-radius: 16px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
}

.gradient-blue { }
.gradient-blue .kpi-icon-wrapper {
  background: linear-gradient(135deg, #5EEAD4, #60A5FA);
}

.gradient-green .kpi-icon-wrapper {
  background: linear-gradient(135deg, #10b981, #059669);
}

.gradient-red .kpi-icon-wrapper {
  background: linear-gradient(135deg, #ef4444, #dc2626);
}

.gradient-purple .kpi-icon-wrapper {
  background: linear-gradient(135deg, #A78BFA, #FB7185);
}

.kpi-content {
  flex: 1;
}

.kpi-label {
  font-size: 13px;
  opacity: 0.7;
  margin-bottom: 4px;
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

.kpi-value {
  font-size: 32px;
  font-weight: 700;
  margin-bottom: 4px;
}

.kpi-trend {
  font-size: 13px;
  opacity: 0.6;
}

.kpi-trend.positive {
  color: #10b981;
}

.kpi-trend.negative {
  color: #ef4444;
}

/* Section Header */
.section-header {
  margin-bottom: 20px;
}

.section-header h2 {
  font-size: 22px;
  font-weight: 600;
}

/* Counters Grid */
.counters-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
  gap: 16px;
  margin-bottom: 32px;
}

.counter-card {
  padding: 20px;
  border-radius: 16px;
  text-align: center;
  transition: all 0.2s;
}

.light-mode .counter-card {
  background: var(--light-surface);
  box-shadow: 6px 6px 12px var(--light-shadow-dark), -6px -6px 12px var(--light-shadow-light);
}

.dark-mode .counter-card {
  background: var(--dark-surface);
  box-shadow: 6px 6px 12px var(--dark-shadow-dark), -6px -6px 12px var(--dark-shadow-light);
}

.counter-card:hover {
  transform: translateY(-2px);
}

.counter-label {
  font-size: 11px;
  text-transform: uppercase;
  opacity: 0.6;
  margin-bottom: 12px;
  letter-spacing: 0.5px;
}

.counter-value {
  font-size: 28px;
  font-weight: 700;
  background: linear-gradient(135deg, #A78BFA, #FB7185);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

/* Charts */
.charts-row {
  display: grid;
  grid-template-columns: 2fr 1fr;
  gap: 20px;
  margin-bottom: 32px;
}

@media (max-width: 1200px) {
  .charts-row {
    grid-template-columns: 1fr;
  }
}

.chart-card {
  padding: 24px;
  border-radius: 20px;
  transition: all 0.3s ease;
}

.chart-card.large {
  grid-column: span 1;
}

.light-mode .chart-card {
  background: var(--light-surface);
  box-shadow: 8px 8px 18px var(--light-shadow-dark), -8px -8px 18px var(--light-shadow-light);
}

.dark-mode .chart-card {
  background: var(--dark-surface);
  box-shadow: 8px 8px 18px var(--dark-shadow-dark), -8px -8px 18px var(--dark-shadow-light);
}

.chart-header {
  margin-bottom: 20px;
}

.chart-header h3 {
  font-size: 18px;
  font-weight: 600;
  display: flex;
  align-items: center;
  gap: 8px;
}

.chart-body {
  min-height: 300px;
}

.pie-legend {
  display: flex;
  flex-direction: column;
  gap: 10px;
  margin-top: 20px;
}

.legend-item {
  display: flex;
  align-items: center;
  gap: 10px;
  font-size: 14px;
}

.legend-color {
  width: 18px;
  height: 18px;
  border-radius: 4px;
  flex-shrink: 0;
}

.legend-label {
  flex: 1;
}

/* Lists Grid */
.lists-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
  gap: 20px;
  margin-bottom: 32px;
}

.list-card {
  padding: 24px;
  border-radius: 20px;
}

.light-mode .list-card {
  background: var(--light-surface);
  box-shadow: 8px 8px 18px var(--light-shadow-dark), -8px -8px 18px var(--light-shadow-light);
}

.dark-mode .list-card {
  background: var(--dark-surface);
  box-shadow: 8px 8px 18px var(--dark-shadow-dark), -8px -8px 18px var(--dark-shadow-light);
}

.list-title {
  font-size: 16px;
  font-weight: 600;
  margin-bottom: 16px;
  display: flex;
  align-items: center;
  gap: 8px;
}

.list-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 12px;
  margin-bottom: 8px;
  border-radius: 10px;
  transition: all 0.2s;
  cursor: pointer;
}

.light-mode .list-item {
  background: rgba(0, 0, 0, 0.02);
}

.dark-mode .list-item {
  background: rgba(255, 255, 255, 0.02);
}

.list-item:hover {
  transform: translateX(4px);
  background: rgba(94, 234, 212, 0.05);
}

.list-text {
  font-size: 13px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  flex: 1;
}

.list-badge {
  padding: 4px 12px;
  border-radius: 8px;
  font-size: 12px;
  font-weight: 600;
  background: linear-gradient(135deg, #5EEAD4, #60A5FA);
  color: white;
}

.list-badge.success {
  background: linear-gradient(135deg, #10b981, #059669);
}

/* Filters Bar */
.filters-bar {
  display: flex;
  gap: 16px;
  margin-bottom: 24px;
  flex-wrap: wrap;
}

.search-box {
  flex: 1;
  min-width: 300px;
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 12px 16px;
  border-radius: 12px;
}

.light-mode .search-box {
  background: var(--light-surface);
  box-shadow: inset 4px 4px 10px var(--light-shadow-dark), inset -4px -4px 10px var(--light-shadow-light);
}

.dark-mode .search-box {
  background: var(--dark-surface);
  box-shadow: inset 4px 4px 10px rgba(0,0,0,0.2), inset -4px -4px 10px rgba(255,255,255,0.02);
}

.search-box input {
  flex: 1;
  border: none;
  background: none;
  outline: none;
  font-size: 14px;
  color: inherit;
}

.filter-select {
  padding: 12px 16px;
  border: none;
  border-radius: 12px;
  font-size: 14px;
  cursor: pointer;
  color: inherit;
}

.light-mode .filter-select {
  background: var(--light-surface);
  box-shadow: 4px 4px 10px var(--light-shadow-dark), -4px -4px 10px var(--light-shadow-light);
}

.dark-mode .filter-select {
  background: var(--dark-surface);
  box-shadow: 4px 4px 10px var(--dark-shadow-dark), -4px -4px 10px var(--dark-shadow-light);
}

/* Table */
.table-card {
  padding: 24px;
  border-radius: 20px;
  margin-bottom: 32px;
}

.light-mode .table-card {
  background: var(--light-surface);
  box-shadow: 8px 8px 18px var(--light-shadow-dark), -8px -8px 18px var(--light-shadow-light);
}

.dark-mode .table-card {
  background: var(--dark-surface);
  box-shadow: 8px 8px 18px var(--dark-shadow-dark), -8px -8px 18px var(--dark-shadow-light);
}

.table-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.table-header h3 {
  font-size: 18px;
  font-weight: 600;
}

.table-wrapper {
  overflow-x: auto;
}

.logs-table {
  width: 100%;
  border-collapse: collapse;
}

.logs-table th {
  text-align: left;
  padding: 12px;
  font-size: 12px;
  font-weight: 600;
  text-transform: uppercase;
  opacity: 0.6;
  border-bottom: 1px solid;
}

.light-mode .logs-table th {
  border-color: rgba(0, 0, 0, 0.06);
}

.dark-mode .logs-table th {
  border-color: rgba(255, 255, 255, 0.06);
}

.logs-table td {
  padding: 14px 12px;
  font-size: 13px;
}

.logs-table tbody tr {
  cursor: pointer;
  transition: all 0.2s;
  border-bottom: 1px solid;
}

.light-mode .logs-table tbody tr {
  border-color: rgba(0, 0, 0, 0.03);
}

.dark-mode .logs-table tbody tr {
  border-color: rgba(255, 255, 255, 0.03);
}

.logs-table tbody tr:hover {
  background: rgba(94, 234, 212, 0.05);
}

.url-cell {
  max-width: 300px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.method-badge {
  padding: 4px 10px;
  border-radius: 6px;
  font-size: 11px;
  font-weight: 600;
  background: rgba(94, 234, 212, 0.1);
  color: #5EEAD4;
}

.event-badge {
  padding: 4px 12px;
  border-radius: 6px;
  font-size: 11px;
  font-weight: 600;
  text-transform: uppercase;
}

.event-allowed {
  background: rgba(16, 185, 129, 0.1);
  color: #10b981;
}

.event-blocked {
  background: rgba(239, 68, 68, 0.1);
  color: #ef4444;
}

/* Modal */
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.6);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
  padding: 20px;
}

.modal-content {
  max-width: 700px;
  width: 100%;
  max-height: 85vh;
  overflow-y: auto;
  padding: 32px;
  border-radius: 20px;
}

.light-mode .modal-content {
  background: var(--light-surface);
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
}

.dark-mode .modal-content {
  background: var(--dark-surface);
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.6);
}

.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 24px;
  padding-bottom: 16px;
  border-bottom: 1px solid;
}

.light-mode .modal-header {
  border-color: rgba(0, 0, 0, 0.06);
}

.dark-mode .modal-header {
  border-color: rgba(255, 255, 255, 0.06);
}

.modal-header h3 {
  font-size: 20px;
  font-weight: 600;
}

.modal-close {
  background: none;
  border: none;
  font-size: 28px;
  cursor: pointer;
  opacity: 0.6;
  transition: opacity 0.2s;
  color: inherit;
  width: 36px;
  height: 36px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 8px;
}

.modal-close:hover {
  opacity: 1;
  background: rgba(239, 68, 68, 0.1);
}

.modal-body {
  font-size: 14px;
  line-height: 1.6;
}

.detail-row {
  display: flex;
  justify-content: space-between;
  padding: 12px 0;
  border-bottom: 1px solid;
}

.light-mode .detail-row {
  border-color: rgba(0, 0, 0, 0.04);
}

.dark-mode .detail-row {
  border-color: rgba(255, 255, 255, 0.04);
}

.detail-row:last-child {
  border-bottom: none;
}

.json-pre {
  padding: 16px;
  border-radius: 12px;
  overflow-x: auto;
  margin-top: 12px;
  font-size: 12px;
  font-family: 'Monaco', 'Courier New', monospace;
}

.light-mode .json-pre {
  background: rgba(0, 0, 0, 0.05);
}

.dark-mode .json-pre {
  background: rgba(0, 0, 0, 0.3);
}

/* Empty States */
.empty-state {
  text-align: center;
  padding: 60px 20px;
  opacity: 0.5;
}

.empty-state p {
  margin-top: 12px;
  font-size: 14px;
}

.empty-state-small {
  text-align: center;
  padding: 40px 20px;
  opacity: 0.5;
  font-size: 14px;
}

.section-placeholder {
  text-align: center;
  padding: 100px 20px;
  opacity: 0.5;
}

.section-placeholder h2 {
  margin-top: 20px;
  font-size: 24px;
}

.section-placeholder p {
  margin-top: 12px;
  font-size: 16px;
}

/* Loading & Animations */
.loading-pulse {
  text-align: center;
  animation: pulse 2s ease-in-out infinite;
}

@keyframes pulse {
  0%, 100% { opacity: 0.6; }
  50% { opacity: 1; }
}

.spin-animation {
  animation: spin 2s linear infinite;
  margin: 0 auto;
}

@keyframes spin {
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
}

.error-container {
  text-align: center;
  padding: 40px;
}

/* Responsive */
@media (max-width: 768px) {
  .sidebar {
    width: var(--sidebar-collapsed);
  }
  
  .sidebar .nav-item span {
    display: none;
  }
  
  .main-content {
    margin-left: var(--sidebar-collapsed);
  }
  
  .content-area {
    padding: 20px;
  }
  
  .kpi-grid {
    grid-template-columns: 1fr;
  }
  
  .charts-row {
    grid-template-columns: 1fr;
  }
  
  .lists-grid {
    grid-template-columns: 1fr;
  }
}
`;

export default Dashboard;